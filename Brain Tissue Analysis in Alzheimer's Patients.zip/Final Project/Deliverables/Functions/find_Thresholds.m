function [T1 T2] = find_Thresholds(image)
%Input Arguments:
%               *image: the image we want to segment and find 2 thresholds
%               for
% Returns:
%               *T1: first threshold
%               *T2: second threshold
% Thresholding is implemented with Otsu's method

im_size = size(image);
tot_pixels = im_size(1)*im_size(2);
sigma_b_sq=zeros(256,1);

for T1 = 1:255
for T2 = T1:255
mu_g=0;
num_pixels_c1 = 0;num_pixels_c2 = 0;num_pixels_c3 = 0;
m1=0;m2=0;m3=0;
    for i = 0:T1
        %counts number of pixels in C1 for P(C1)
        num_pixels_c1 = num_pixels_c1 + nnz(image == i);
        %m1 is SIGMA(iP(i)) as i<=T1
        m1 = m1 + i*(nnz(image == i)/tot_pixels);
        mu_g = mu_g + i*(nnz(image == i)/tot_pixels);
    end
    for j = T1+1:T2
        %counts number of pixels in C2 for P(C2)
        num_pixels_c2 = num_pixels_c2 + nnz(image == j);
        %m2 is SIGMA(jP(j)) as T2>j>T1
        m2 = m2 + j*(nnz(image == j)/tot_pixels);
        mu_g = mu_g + (j*nnz(image == j)/tot_pixels);
    end
    for k = T2+1:255
        %counts number of pixels in C3 for P(C2)
        num_pixels_c3 = num_pixels_c3 + nnz(image == k);
        %m3 is SIGMA(kP(k)) as k>T2
        m3 = m3 + (k*nnz(image == k)/tot_pixels);
        mu_g = mu_g + (k*nnz(image == k)/tot_pixels);
    end
    
    Pc1 = num_pixels_c1/tot_pixels; 
    Pc2 = num_pixels_c2/tot_pixels; 
    Pc3 = num_pixels_c3/tot_pixels;
    sigma_b_sq(T1,T2) = Pc1*(m1-mu_g)^2 + Pc2*(m2-mu_g)^2 +Pc3*(m3-mu_g);
end
end

[max_sigma,T2] = max(max(sigma_b_sq));
[max_sigam,T1] = max(sigma_b_sq(:,T2));
T1 = T1;
T2 = T2;



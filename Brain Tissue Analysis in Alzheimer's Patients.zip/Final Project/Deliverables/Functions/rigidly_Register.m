function [registered_image] = rigidly_Register(follow_up, follow_up_landmarks, base_line_landmarks)
% Input Arguments:
%                *follow_up: image to be registered
%                *follow_up_landmarks: landmarks of the follow up image
%                *base_line_landmarks: landmarks from the baseline image
% Output Arguements:
%                *registered_image = regidly registered follow up image

%Calculate center
num_landmarks = size(base_line_landmarks);
baseline_center = [sum(base_line_landmarks(:,1))/num_landmarks(1),sum(base_line_landmarks(:,2))/num_landmarks(1)];
follow_up_center = [sum(follow_up_landmarks(:,1))/num_landmarks(1),sum(follow_up_landmarks(:,2))/num_landmarks(1)];

%Compute covariance
Covariance = cov(base_line_landmarks,follow_up_landmarks);

[U,D,V] = svd(Covariance);

if det(D)>=1
    
    S = [1 0; 0 1];
    
elseif det(D)< 1
    
    S = [1 0; 0 -1];

end

%Amount of rotation
best_R = U*S*V';

%Amount of translation
best_T = baseline_center-(best_R*follow_up_center')';

%convert from radians to degrees
theta = rad2deg(acos(best_R(1,1)));
theta = norm(theta);

%Imaginary value check
registered_image = imrotate(follow_up,-theta);
if size(follow_up)~= size(registered_image)
    registered_image = registered_image(1:end-1,1:end-1);
end
registered_image = imtranslate(registered_image,-best_T);







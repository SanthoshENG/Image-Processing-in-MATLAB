function [segmented_Image CSF GM WM] = segment_Image(image, T1, T2)
%Input Arguments:
%               *image: the image we want to segment 
%               *T1: first threshold
%               *T2: second threshold
% Returns:
%               *segmented_Image: final segmented Image in 3 classes
%               *CSF: number of CSF pixels
%               *GM: number of GM pixels
%               *WM: number of WM pixels
CSF = 0;
GM = 0;
WM = 0;

im_size = size(image);
segmented_Image = zeros(im_size);
for i = 1:im_size(1)
    for j = 1:im_size(2)
        if image(i,j) <= T1
            segmented_Image(i,j) = 0;
            CSF = CSF + 1;
        elseif T1<image(i,j) && image(i,j) <= T2
            segmented_Image(i,j) = 128;
            GM = GM+1;
        else
            segmented_Image(i,j) = 256;
            WM = WM+1;
        end
    end
end
segmented_Image = segmented_Image;
function [percent_change] = calculate_percent_change(array)
%Input Arguments:
%               *array: must have two columns to find the percent change between the two 
% Returns:
%               *percent_change: array with percent change between each row
%               This is a single column vector

temp = array(:,1);
array = array(:,2)-array(:,1);
percent_change = (array./temp).*100;

end
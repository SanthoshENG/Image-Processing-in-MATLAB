function [disp_x disp_y] = dispField(im_rows, im_cols, temp_cols, temp_rows, tar_cols, tar_rows, sigma)

% Input Arguments:
%                *im_rows: number of image rows
%                *im_cols: number of image cols
%                *temp_cols: x cooridinates of template landmarks
%                *temp_rows: y cooridinates of template landmarks
%                *tar_cols: x cooridinates of target landmarks
%                *tar_rows: y cooridinates of target landmarks
%                *sigma: variance for the Gaussian
% Returns:
%                *disp_x = displacement in the x direction of each pixel
%                of the image, returns a matrix the size of the image
%                *disp_y = displacement in the y direction of each pixel of
%                the image, returns a matrix the size of the image 

%Finding displacements between template and target landmarks
u_rows = tar_rows - temp_rows;
u_cols = tar_cols - temp_cols;
num_landmarks = size(u_rows);
sigma_squared = 2*sigma^2;
disp_x = zeros(im_rows,im_cols);
disp_y = zeros(im_rows,im_cols);

for i=1:im_rows %y value
    for j=1:im_cols %x value
        for k=1:num_landmarks(2) %number of landmarks
            disp_x(i,j) = disp_x(i,j)+((exp(-1*((i-temp_rows(k))^2+(j-temp_cols(k))^2)/(2*sigma_squared))*u_cols(k)));
            disp_y(i,j) = disp_y(i,j)+((exp(-1*((i-temp_rows(k))^2+(j-temp_cols(k))^2)/(2*sigma_squared))*u_rows(k)));
        end
    end
end

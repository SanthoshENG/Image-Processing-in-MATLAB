%%
% Final Project
% Santhosh Nandakumar
% 301300261
% snandaku@sfu.ca
% Running this file will provide with all the outputs
% To see more detailed outlining of code please navigate to ./Deliverables
% directory where all outputs/code can be found
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Part 1 Rigid Registration
clear all;
close all
clc;
addpath('./Deliverables/2019_ENSC474_PROJECT_images/images');
addpath('./Deliverables/Functions');


AD_1_BL = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/AD_1_BL.jpeg');
AD_1_M24 = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/AD_1_M24.jpeg');

% [baseline1_points, follow_up1_points] = cpselect(AD_1_BL, AD_1_M24,'wait',true);
% save('Landmarks_AD_1_BL', 'baseline1_points');
% save('Landmarks_AD_1_M24', 'follow_up1_points');

load('Part 1 Landmarks/Landmarks_AD_1_BL', 'baseline1_points');
load('Part 1 Landmarks/Landmarks_AD_1_M24', 'follow_up1_points');

AD_1_M24_Reg = rigidly_Register(AD_1_M24,baseline1_points, follow_up1_points);
difference1 = AD_1_M24_Reg - AD_1_BL;

% figure('units','normalized','outerposition',[0 0 1 1]);
% subplot(1,3,1)
% imshowpair(AD_1_BL,AD_1_M24)
% title('Unregistered AD Patient 1')
% subplot(1,3,2)
% imshowpair(AD_1_BL,AD_1_M24_Reg)
% title('Registered AD Patient 1')
% subplot(1,3,3)
% imshow(difference1)
% title('Difference Image AD Patient 1')

%%
AD_2_BL = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/AD_2_BL.jpeg');
AD_2_M24 = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/AD_2_M24.jpeg');

load('Part 1 Landmarks/Landmarks_AD_2_BL', 'baseline2_points');
load('Part 1 Landmarks/Landmarks_AD_2_M24', 'follow_up2_points');

AD_2_M24_Reg = rigidly_Register(AD_2_M24,baseline2_points, follow_up2_points);
difference2 = AD_2_M24_Reg - AD_2_BL;
    
% figure('units','normalized','outerposition',[0 0 1 1]);
% subplot(1,3,1)
% imshowpair(AD_2_BL,AD_2_M24)
% title('Unregistered AD Patient 2')
% subplot(1,3,2)
% imshowpair(AD_2_BL,AD_2_M24_Reg)
% title('Registered AD Patient 2')
% subplot(1,3,3)
% imshow(difference2)
% title('Difference Image AD Patient 2')

%%
AD_3_BL = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/AD_3_BL.jpeg');
AD_3_M24 = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/AD_3_M24.jpeg');

load('Part 1 Landmarks/Landmarks_AD_3_BL', 'baseline3_points');
load('Part 1 Landmarks/Landmarks_AD_3_M24', 'follow_up3_points');

AD_3_M24_Reg = rigidly_Register(AD_3_M24,baseline3_points, follow_up3_points);
difference3 = AD_3_M24_Reg - AD_3_BL;
    
% figure('units','normalized','outerposition',[0 0 1 1]);
% subplot(1,3,1)
% imshowpair(AD_3_BL,AD_3_M24)
% title('Unregistered AD Patient 3')
% subplot(1,3,2)
% imshowpair(AD_3_BL,AD_3_M24_Reg)
% title('Registered AD Patient 3')
% subplot(1,3,3)
% imshow(difference3)
% title('Difference Image AD Patient 3')

%%
AD_4_BL = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/AD_4_BL.jpeg');
AD_4_M24 = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/AD_4_M24.jpeg');

load('Part 1 Landmarks/Landmarks_AD_4_BL', 'baseline4_points');
load('Part 1 Landmarks/Landmarks_AD_4_M24', 'follow_up4_points');

AD_4_M24_Reg = rigidly_Register(AD_4_M24,baseline4_points, follow_up4_points);
difference4 = AD_4_M24_Reg - AD_4_BL;
    
% figure('units','normalized','outerposition',[0 0 1 1]);
% subplot(1,3,1)
% imshowpair(AD_4_BL,AD_4_M24)
% title('Unregistered AD Patient 4')
% subplot(1,3,2)
% imshowpair(AD_4_BL,AD_4_M24_Reg)
% title('Registered AD Patient 4')
% subplot(1,3,3)
% imshow(difference4)
% title('Difference Image AD Patient 4')

%%
AD_5_BL = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/AD_5_BL.jpeg');
AD_5_M24 = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/AD_5_M24.jpeg');

load('Part 1 Landmarks/Landmarks_AD_5_BL', 'baseline5_points');
load('Part 1 Landmarks/Landmarks_AD_5_M24', 'follow_up5_points');

AD_5_M24_Reg = rigidly_Register(AD_5_M24,baseline5_points, follow_up5_points);
difference5 = AD_5_M24_Reg - AD_5_BL;
    
% figure('units','normalized','outerposition',[0 0 1 1]);
% subplot(1,3,1)
% imshowpair(AD_5_BL,AD_5_M24)
% title('Unregistered AD Patient 5')
% subplot(1,3,2)
% imshowpair(AD_5_BL,AD_5_M24_Reg)
% title('Registered AD Patient 5')
% subplot(1,3,3)
% imshow(difference5)
% title('Difference Image AD Patient 5')

%%
AD_6_BL = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/AD_6_BL.jpeg');
AD_6_M24 = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/AD_6_M24.jpeg');

load('Part 1 Landmarks/Landmarks_AD_6_BL', 'baseline6_points');
load('Part 1 Landmarks/Landmarks_AD_6_M24', 'follow_up6_points');

AD_6_M24_Reg = rigidly_Register(AD_6_M24,baseline6_points, follow_up6_points);
difference6 = AD_6_M24_Reg - AD_6_BL;
    
% figure('units','normalized','outerposition',[0 0 1 1]);
% subplot(1,3,1)
% imshowpair(AD_6_BL,AD_6_M24)
% title('Unregistered AD Patient 6')
% subplot(1,3,2)
% imshowpair(AD_6_BL,AD_6_M24_Reg)
% title('Registered AD Patient 6')
% subplot(1,3,3)
% imshow(difference6)
% title('Difference Image AD Patient 6')

%%
AD_7_BL = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/AD_7_BL.jpeg');
AD_7_M24 = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/AD_7_M24.jpeg');

load('Part 1 Landmarks/Landmarks_AD_7_BL', 'baseline7_points');
load('Part 1 Landmarks/Landmarks_AD_7_M24', 'follow_up7_points');

AD_7_M24_Reg = rigidly_Register(AD_7_M24,baseline7_points, follow_up7_points);
difference7 = AD_7_M24_Reg - AD_7_BL;
    
% figure('units','normalized','outerposition',[0 0 1 1]);
% subplot(1,3,1)
% imshowpair(AD_7_BL,AD_7_M24)
% title('Unregistered AD Patient 7')
% subplot(1,3,2)
% imshowpair(AD_7_BL,AD_7_M24_Reg)
% title('Registered AD Patient 7')
% subplot(1,3,3)
% imshow(difference7)
% title('Difference Image AD Patient 7')
%%
AD_8_BL = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/AD_8_BL.jpeg');
AD_8_M24 = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/AD_8_M24.jpeg');

load('Part 1 Landmarks/Landmarks_AD_8_BL', 'baseline8_points');
load('Part 1 Landmarks/Landmarks_AD_8_M24', 'follow_up8_points');

AD_8_M24_Reg = rigidly_Register(AD_8_M24,baseline8_points, follow_up8_points);
difference8 = AD_8_M24_Reg - AD_8_BL;
    
% figure('units','normalized','outerposition',[0 0 1 1]);
% subplot(1,3,1)
% imshowpair(AD_8_BL,AD_8_M24)
% title('Unregistered AD Patient 8')
% subplot(1,3,2)
% imshowpair(AD_8_BL,AD_8_M24_Reg)
% title('Registered AD Patient 8')
% subplot(1,3,3)
% imshow(difference8)
% title('Difference Image AD Patient 8')

%%
AD_9_BL = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/AD_9_BL.jpeg');
AD_9_M24 = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/AD_9_M24.jpeg');

load('Part 1 Landmarks/Landmarks_AD_9_BL', 'baseline9_points');
load('Part 1 Landmarks/Landmarks_AD_9_M24', 'follow_up9_points');

AD_9_M24_Reg = rigidly_Register(AD_9_M24,baseline9_points, follow_up9_points);
difference9 = AD_9_M24_Reg - AD_9_BL;
    
% figure('units','normalized','outerposition',[0 0 1 1]);
% subplot(1,3,1)
% imshowpair(AD_9_BL,AD_9_M24)
% title('Unregistered AD Patient 9')
% subplot(1,3,2)
% imshowpair(AD_9_BL,AD_9_M24_Reg)
% title('Registered AD Patient 9')
% subplot(1,3,3)
% imshow(difference9)
% title('Difference Image AD Patient 9')

%%
AD_10_BL = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/AD_10_BL.jpeg');
AD_10_M24 = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/AD_10_M24.jpeg');

load('Part 1 Landmarks/Landmarks_AD_10_BL', 'baseline10_points');
load('Part 1 Landmarks/Landmarks_AD_10_M24', 'follow_up10_points');

AD_10_M24_Reg = rigidly_Register(AD_10_M24,baseline10_points, follow_up10_points);
difference10 = AD_10_M24_Reg - AD_10_BL;
    
% figure('units','normalized','outerposition',[0 0 1 1]);
% subplot(1,3,1)
% imshowpair(AD_10_BL,AD_10_M24)
% title('Unregistered AD Patient 10')
% subplot(1,3,2)
% imshowpair(AD_10_BL,AD_10_M24_Reg)
% title('Registered AD Patient 10')
% subplot(1,3,3)
% imshow(difference10)
% title('Difference Image AD Patient 10')

%%
CN_1_BL = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/CN_1_BL.jpeg');
CN_1_M24 = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/CN_1_M24.jpeg');

load('Part 1 Landmarks/Landmarks_CN_1_BL', 'baseline1_points');
load('Part 1 Landmarks/Landmarks_CN_1_M24', 'follow_up1_points');

CN_1_M24_Reg = rigidly_Register(CN_1_M24,baseline1_points, follow_up1_points);
difference_h1 = CN_1_M24_Reg - CN_1_BL;
    
% figure('units','normalized','outerposition',[0 0 1 1]);
% subplot(1,3,1)
% imshowpair(CN_1_BL,CN_1_M24)
% title('Unregistered CN Patient 1')
% subplot(1,3,2)
% imshowpair(CN_1_BL,CN_1_M24_Reg)
% title('Registered CN Patient 1')
% subplot(1,3,3)
% imshow(difference_h1)
% title('Difference Image CN Patient 1')

%%
CN_2_BL = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/CN_2_BL.jpeg');
CN_2_M24 = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/CN_2_M24.jpeg');

load('Part 1 Landmarks/Landmarks_CN_2_BL', 'baseline2_points');
load('Part 1 Landmarks/Landmarks_CN_2_M24', 'follow_up2_points');

CN_2_M24_Reg = rigidly_Register(CN_2_M24,baseline2_points, follow_up2_points);
difference_h2 = CN_2_M24_Reg - CN_2_BL;
    
% figure('units','normalized','outerposition',[0 0 1 1]);
% subplot(1,3,1)
% imshowpair(CN_2_BL,CN_2_M24)
% title('Unregistered CN Patient 2')
% subplot(1,3,2)
% imshowpair(CN_2_BL,CN_2_M24_Reg)
% title('Registered CN Patient 2')
% subplot(1,3,3)
% imshow(difference_h2)
% title('Difference Image CN Patient 2')

%%
CN_3_BL = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/CN_3_BL.jpeg');
CN_3_M24 = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/CN_3_M24.jpeg');

load('Part 1 Landmarks/Landmarks_CN_3_BL', 'baseline3_points');
load('Part 1 Landmarks/Landmarks_CN_3_M24', 'follow_up3_points');

CN_3_M24_Reg = rigidly_Register(CN_3_M24,baseline3_points, follow_up3_points);
difference_h3 = CN_3_M24_Reg - CN_3_BL;
    
% figure('units','normalized','outerposition',[0 0 1 1]);
% subplot(1,3,1)
% imshowpair(CN_3_BL,CN_3_M24)
% title('Unregistered CN Patient 3')
% subplot(1,3,2)
% imshowpair(CN_3_BL,CN_3_M24_Reg)
% title('Registered CN Patient 3')
% subplot(1,3,3)
% imshow(difference_h3)
% title('Difference Image CN Patient 3')
%%
CN_4_BL = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/CN_4_BL.jpeg');
CN_4_M24 = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/CN_4_M24.jpeg');

load('Part 1 Landmarks/Landmarks_CN_4_BL', 'baseline4_points');
load('Part 1 Landmarks/Landmarks_CN_4_M24', 'follow_up4_points');

CN_4_M24_Reg = rigidly_Register(CN_4_M24,baseline4_points, follow_up4_points);
difference_h4 = CN_4_M24 - CN_4_BL;
    
% figure('units','normalized','outerposition',[0 0 1 1]);
% subplot(1,3,1)
% imshowpair(CN_4_BL,CN_4_M24_Reg)
% title('Unregistered CN Patient 4')
% subplot(1,3,2)
% imshowpair(CN_4_BL,CN_4_M24)
% title('Registered CN Patient 4')
% subplot(1,3,3)
% imshow(difference_h4)
% title('Difference Image CN Patient 4')
%%
CN_5_BL = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/CN_5_BL.jpeg');
CN_5_M24 = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/CN_5_M24.jpeg');

load('Part 1 Landmarks/Landmarks_CN_5_BL', 'baseline5_points');
load('Part 1 Landmarks/Landmarks_CN_5_M24', 'follow_up5_points');

CN_5_M24_Reg = rigidly_Register(CN_5_M24,baseline5_points, follow_up5_points);
difference_h5 = CN_5_M24_Reg - CN_5_BL;
    
% figure('units','normalized','outerposition',[0 0 1 1]);
% subplot(1,3,1)
% imshowpair(CN_5_BL,CN_5_M24)
% title('Unregistered CN Patient 5')
% subplot(1,3,2)
% imshowpair(CN_5_BL,CN_5_M24_Reg)
% title('Registered CN Patient 5')
% subplot(1,3,3)
% imshow(difference_h5)
% title('Difference Image CN Patient 5')
%%
CN_6_BL = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/CN_6_BL.jpeg');
CN_6_M24 = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/CN_6_M24.jpeg');

load('Part 1 Landmarks/Landmarks_CN_6_BL', 'baseline6_points');
load('Part 1 Landmarks/Landmarks_CN_6_M24', 'follow_up6_points');

CN_6_M24_Reg = rigidly_Register(CN_6_M24,baseline6_points, follow_up6_points);
difference_h6 = CN_6_M24_Reg - CN_6_BL;
    
% figure('units','normalized','outerposition',[0 0 1 1]);
% subplot(1,3,1)
% imshowpair(CN_6_BL,CN_6_M24)
% title('Unregistered CN Patient 6')
% subplot(1,3,2)
% imshowpair(CN_6_BL,CN_6_M24_Reg)
% title('Registered CN Patient 6')
% subplot(1,3,3)
% imshow(difference_h6)
% title('Difference Image CN Patient 6')
%%
CN_7_BL = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/CN_7_BL.jpeg');
CN_7_M24 = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/CN_7_M24.jpeg');

load('Part 1 Landmarks/Landmarks_CN_7_BL', 'baseline7_points');
load('Part 1 Landmarks/Landmarks_CN_7_M24', 'follow_up7_points');

CN_7_M24_Reg = rigidly_Register(CN_7_M24,baseline7_points, follow_up7_points);
difference_h7 = CN_7_M24_Reg - CN_7_BL;
    
% figure('units','normalized','outerposition',[0 0 1 1]);
% subplot(1,3,1)
% imshowpair(CN_7_BL,CN_7_M24)
% title('Unregistered CN Patient 7')
% subplot(1,3,2)
% imshowpair(CN_7_BL,CN_7_M24_Reg)
% title('Registered CN Patient 7')
% subplot(1,3,3)
% imshow(difference_h7)
% title('Difference Image CN Patient 7')
%%
CN_8_BL = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/CN_8_BL.jpeg');
CN_8_M24 = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/CN_8_M24.jpeg');

load('Part 1 Landmarks/Landmarks_CN_8_BL', 'baseline8_points');
load('Part 1 Landmarks/Landmarks_CN_8_M24', 'follow_up8_points');

CN_8_M24_Reg = rigidly_Register(CN_8_M24,baseline8_points, follow_up8_points);
difference_h8 = CN_8_M24_Reg - CN_8_BL;
    
% figure('units','normalized','outerposition',[0 0 1 1]);
% subplot(1,3,1)
% imshowpair(CN_8_BL,CN_8_M24)
% title('Unregistered CN Patient 8')
% subplot(1,3,2)
% imshowpair(CN_8_BL,CN_8_M24_Reg)
% title('Registered CN Patient 8')
% subplot(1,3,3)
% imshow(difference_h8)
% title('Difference Image CN Patient 8')
%%
CN_9_BL = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/CN_9_BL.jpeg');
CN_9_M24 = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/CN_9_M24.jpeg');

load('Part 1 Landmarks/Landmarks_CN_9_BL', 'baseline9_points');
load('Part 1 Landmarks/Landmarks_CN_9_M24', 'follow_up9_points');

CN_9_M24_Reg = rigidly_Register(CN_9_M24,baseline9_points, follow_up9_points);
difference_h9 = CN_9_M24_Reg - CN_9_BL;
    
% figure('units','normalized','outerposition',[0 0 1 1]);
% subplot(1,3,1)
% imshowpair(CN_9_BL,CN_9_M24)
% title('Unregistered CN Patient 9')
% subplot(1,3,2)
% imshowpair(CN_9_BL,CN_9_M24_Reg)
% title('Registered CN Patient 9')
% subplot(1,3,3)
% imshow(difference_h9)
% title('Difference Image CN Patient 9')
%%
CN_10_BL = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/CN_10_BL.jpeg');
CN_10_M24 = imread('./Deliverables/2019_ENSC474_PROJECT_images/images/CN_10_M24.jpeg');

load('Part 1 Landmarks/Landmarks_CN_10_BL', 'baseline10_points');
load('Part 1 Landmarks/Landmarks_CN_10_M24', 'follow_up10_points');

CN_10_M24_Reg = rigidly_Register(CN_10_M24,baseline10_points, follow_up10_points);
difference_h10 = CN_10_M24_Reg - CN_10_BL;
    
% figure('units','normalized','outerposition',[0 0 1 1]);
% subplot(1,3,1)
% imshowpair(CN_10_BL,CN_10_M24)
% title('Unregistered CN Patient 10')
% subplot(1,3,2)
% imshowpair(CN_10_BL,CN_10_M24_Reg)
% title('Registered CN Patient 10')
% subplot(1,3,3)
% imshow(difference_h10)
% title('Difference Image CN Patient 10')

figure('units','normalized','outerposition',[0 0 1 1]);
subplot(2,5,1);imshow(difference1);title('AD Patient 1');
subplot(2,5,2);imshow(difference2);title('AD Patient 2');
subplot(2,5,3);imshow(difference3);title('AD Patient 3');
subplot(2,5,4);imshow(difference4);title('AD Patient 4');
subplot(2,5,5);imshow(difference5);title('AD Patient 5');
subplot(2,5,6);imshow(difference6);title('AD Patient 6');
subplot(2,5,7);imshow(difference7);title('AD Patient 7');
subplot(2,5,8);imshow(difference8);title('AD Patient 8');
subplot(2,5,9);imshow(difference9);title('AD Patient 9');
subplot(2,5,10);imshow(difference10);title('AD Patient 10');

figure('units','normalized','outerposition',[0 0 1 1]);
subplot(2,5,1);imshow(difference_h1);title('CN Patient 1');
subplot(2,5,2);imshow(difference_h2);title('CN Patient 2');
subplot(2,5,3);imshow(difference_h3);title('CN Patient 3');
subplot(2,5,4);imshow(difference_h4);title('CN Patient 4');
subplot(2,5,5);imshow(difference_h5);title('CN Patient 5');
subplot(2,5,6);imshow(difference_h6);title('CN Patient 6');
subplot(2,5,7);imshow(difference_h7);title('CN Patient 7');
subplot(2,5,8);imshow(difference_h8);title('CN Patient 8');
subplot(2,5,9);imshow(difference_h9);title('CN Patient 9');
subplot(2,5,10);imshow(difference_h10);title('CN Patient 10');
%% Part 2 Non-rigid Registration
%Landmarks are chosen based on moving matter(pixels)
%Landmarks passed through dispField function which will compute how far
%pixels are moving using a Gaussian approximation
%This information is used to construct a transformation grid

load('Part 2 Landmarks/Landmarks_AD_2_BL', 'baselineNR2_points');
load('Part 2 Landmarks/Landmarks_AD_2_M24', 'follow_upNR2_points');

im_size = size(AD_2_BL); im_rows = im_size(1); im_cols = im_size(2);
temp_cols = baselineNR2_points(:,1)'; temp_rows = baselineNR2_points(:,2)'; tar_cols = follow_upNR2_points(:,1)'; tar_rows = follow_upNR2_points(:,2)';
sigma = 1;
%Function dispField used to show how matter (pixels) are changing
[d_x d_y] = dispField(im_rows,im_cols,temp_cols,temp_rows,tar_cols,tar_rows,sigma);
%Sets up transformation grid
[X Y] = meshgrid(1:im_cols, 1:im_rows);
phi_x = X + d_x;
phi_y = Y + d_y;

figure('units','normalized','outerposition',[0 0 1 1]);
subplot(1,3,1);
plot(phi_x,phi_y);xlim([1,im_cols]);ylim([1,im_rows]);
title('Transformation Grid AD Patient 2');xlabel('X (columns)');ylabel('Y (rows)');
set(gca,'ydir','reverse');

%The above process is repeated for 3 randomly chosen AD patients and 3
%randomly chosen CN patients

load('Part 2 Landmarks/Landmarks_AD_4_BL', 'baselineNR4_points');
load('Part 2 Landmarks/Landmarks_AD_4_M24', 'follow_upNR4_points');

im_size = size(AD_4_BL); im_rows = im_size(1); im_cols = im_size(2);
temp_cols = baselineNR4_points(:,1)';temp_rows = baselineNR4_points(:,2)';tar_cols = follow_upNR4_points(:,1)';tar_rows = follow_upNR4_points(:,2)';
[d_x d_y] = dispField(im_rows,im_cols,temp_cols,temp_rows,tar_cols,tar_rows,sigma);

[X Y] = meshgrid(1:im_cols, 1:im_rows);
phi_x = X + d_x;
phi_y = Y + d_y;

subplot(1,3,2);
plot(phi_x,phi_y);xlim([1,im_cols]);ylim([1,im_rows]);
title('Transformation Grid AD Patient 4'); xlabel('X (columns)'); ylabel('Y (rows)')
set(gca,'ydir','reverse');

load('Part 2 Landmarks/Landmarks_AD_8_BL', 'baselineNR8_points');
load('Part 2 Landmarks/Landmarks_AD_8_M24', 'follow_upNR8_points');

im_size = size(AD_8_BL); im_rows = im_size(1); im_cols = im_size(2);
temp_cols = baselineNR8_points(:,1)';temp_rows = baselineNR8_points(:,2)';tar_cols = follow_upNR8_points(:,1)';tar_rows = follow_upNR8_points(:,2)';
[d_x d_y] = dispField(im_rows,im_cols,temp_cols,temp_rows,tar_cols,tar_rows,sigma);

[X Y] = meshgrid(1:im_cols, 1:im_rows);
phi_x = X + d_x;
phi_y = Y + d_y;

subplot(1,3,3);
plot(phi_x,phi_y);xlim([1,im_cols]);ylim([1,im_rows]);
title('Transformation Grid AD Patient 8');xlabel('X (columns)');ylabel('Y (rows)')
set(gca,'ydir','reverse');

load('Part 2 Landmarks/Landmarks_CN_2_BL', 'baselineCNR2_points');
load('Part 2 Landmarks/Landmarks_CN_2_M24', 'follow_upCNR2_points');

im_size = size(CN_2_BL); im_rows = im_size(1); im_cols = im_size(2);temp_cols = baselineCNR2_points(:,1)';temp_rows = baselineCNR2_points(:,2)';tar_cols = follow_upCNR2_points(:,1)';tar_rows = follow_upCNR2_points(:,2)';

[d_x d_y] = dispField(im_rows,im_cols,temp_cols,temp_rows,tar_cols,tar_rows,sigma);

[X Y] = meshgrid(1:im_cols, 1:im_rows);
phi_x = X + d_x;
phi_y = Y + d_y;

figure('units','normalized','outerposition',[0 0 1 1]);
subplot(1,3,1);
plot(phi_x,phi_y);xlim([1,im_cols]);ylim([1,im_rows]);
title('Transformation Grid CN Patient 2');xlabel('X (columns)');ylabel('Y (rows)')
set(gca,'ydir','reverse');

load('Part 2 Landmarks/Landmarks_CN_4_BL', 'baselineCNR4_points');
load('Part 2 Landmarks/Landmarks_CN_4_M24', 'follow_upCNR4_points');

im_size = size(CN_4_BL); im_rows = im_size(1); im_cols = im_size(2);
temp_cols = baselineCNR4_points(:,1)';temp_rows = baselineCNR4_points(:,2)';tar_cols = follow_upCNR4_points(:,1)';tar_rows = follow_upCNR4_points(:,2)';
[d_x d_y] = dispField(im_rows,im_cols,temp_cols,temp_rows,tar_cols,tar_rows,sigma);

[X Y] = meshgrid(1:im_cols, 1:im_rows);
phi_x = X + d_x;
phi_y = Y + d_y;

subplot(1,3,2);
plot(phi_x,phi_y);xlim([1,im_cols]);ylim([1,im_rows]);
title('Transformation Grid CN Patient 4');xlabel('X (columns)');ylabel('Y (rows)')
set(gca,'ydir','reverse');


load('Part 2 Landmarks/Landmarks_CN_8_BL', 'baselineNRC8_points');
load('Part 2 Landmarks/Landmarks_CN_8_M24', 'follow_upNRC8_points');

im_size = size(CN_8_BL); im_rows = im_size(1); im_cols = im_size(2);temp_cols = baselineNRC8_points(:,1)';temp_rows = baselineNRC8_points(:,2)';tar_cols = follow_upNRC8_points(:,1)';tar_rows = follow_upNRC8_points(:,2)';
[d_x d_y] = dispField(im_rows,im_cols,temp_cols,temp_rows,tar_cols,tar_rows,sigma);

[X Y] = meshgrid(1:im_cols, 1:im_rows);
phi_x = X + d_x;
phi_y = Y + d_y;

subplot(1,3,3)
plot(phi_x,phi_y);xlim([1,im_cols]);ylim([1,im_rows]);
title('Transformation Grid CN Patient 8');xlabel('X (columns)');ylabel('Y (rows)')
set(gca,'ydir','reverse');
%% Image Segmentation

% [T1 T2] = find_Thresholds(AD_1_BL)
% final_Image = segment_Image(AD_1_BL,T1,T2);

T1 = 13; %11
T2 = 68; %63
[seg_AD_1_BL CSF_B1 GM_B1 WM_B1] = segment_Image(AD_1_BL,T1,T2);
[seg_AD_2_BL CSF_B2 GM_B2 WM_B2] = segment_Image(AD_2_BL,T1,T2);
[seg_AD_3_BL CSF_B3 GM_B3 WM_B3]  = segment_Image(AD_3_BL,T1,T2);
[seg_AD_4_BL CSF_B4 GM_B4 WM_B4] = segment_Image(AD_4_BL,T1,63);
[seg_AD_5_BL CSF_B5 GM_B5 WM_B5] = segment_Image(AD_5_BL,T1,T2);
[seg_AD_6_BL CSF_B6 GM_B6 WM_B6] = segment_Image(AD_6_BL,T1,T2);
[seg_AD_7_BL CSF_B7 GM_B7 WM_B7] = segment_Image(AD_7_BL,10,73);
[seg_AD_8_BL CSF_B8 GM_B8 WM_B8] = segment_Image(AD_8_BL,T1,T2);
[seg_AD_9_BL CSF_B9 GM_B9 WM_B9] = segment_Image(AD_9_BL,T1,T2);
[seg_AD_10_BL CSF_B10 GM_B10 WM_B10] = segment_Image(AD_10_BL,T1,T2);

[seg_AD_1_M24 CSF_M1 GM_M1 WM_M1] = segment_Image(AD_1_M24_Reg,T1,T2);
[seg_AD_2_M24 CSF_M2 GM_M2 WM_M2] = segment_Image(AD_2_M24_Reg,T1,T2);
[seg_AD_3_M24 CSF_M3 GM_M3 WM_M3] = segment_Image(AD_3_M24_Reg,T1,T2);
[seg_AD_4_M24 CSF_M4 GM_M4 WM_M4] = segment_Image(AD_4_M24_Reg,T1,T2);
[seg_AD_5_M24 CSF_M5 GM_M5 WM_M5] = segment_Image(AD_5_M24_Reg,T1,T2);
[seg_AD_6_M24 CSF_M6 GM_M6 WM_M6]= segment_Image(AD_6_M24_Reg,T1,T2);
[seg_AD_7_M24 CSF_M7 GM_M7 WM_M7] = segment_Image(AD_7_M24_Reg,T1,T2);
[seg_AD_8_M24 CSF_M8 GM_M8 WM_M8] = segment_Image(AD_8_M24_Reg,T1,T2);
[seg_AD_9_M24 CSF_M9 GM_M9 WM_M9] = segment_Image(AD_9_M24_Reg,T1,T2);
[seg_AD_10_M24 CSF_M10 GM_M10 WM_M10]= segment_Image(AD_10_M24_Reg,T1,T2);

[seg_CN_1_BL CSF_CB1 GM_CB1 WM_CB1] = segment_Image(CN_1_BL,T1,T2);
[seg_CN_2_BL CSF_CB2 GM_CB2 WM_CB2] = segment_Image(CN_2_BL,T1,T2);
[seg_CN_3_BL CSF_CB3 GM_CB3 WM_CB3]= segment_Image(CN_3_BL,T1,T2);
[seg_CN_4_BL CSF_CB4 GM_CB4 WM_CB4] = segment_Image(CN_4_BL,T1,63);
[seg_CN_5_BL CSF_CB5 GM_CB5 WM_CB5] = segment_Image(CN_5_BL,T1,T2);
[seg_CN_6_BL CSF_CB6 GM_CB6 WM_CB6] = segment_Image(CN_6_BL,T1,T2);
[seg_CN_7_BL CSF_CB7 GM_CB7 WM_CB7] = segment_Image(CN_7_BL,10,73);
[seg_CN_8_BL CSF_CB8 GM_CB8 WM_CB8] = segment_Image(CN_8_BL,T1,T2);
[seg_CN_9_BL CSF_CB9 GM_CB9 WM_CB9] = segment_Image(CN_9_BL,T1,T2);
[seg_CN_10_BL CSF_CB10 GM_CB10 WM_CB10] = segment_Image(CN_10_BL,T1,T2);

[seg_CN_1_M24 CSF_CM1 GM_CM1 WM_CM1] = segment_Image(CN_1_M24_Reg,T1,T2);
[seg_CN_2_M24 CSF_CM2 GM_CM2 WM_CM2]= segment_Image(CN_2_M24_Reg,T1,T2);
[seg_CN_3_M24 CSF_CM3 GM_CM3 WM_CM3]= segment_Image(CN_3_M24_Reg,T1,T2);
[seg_CN_4_M24 CSF_CM4 GM_CM4 WM_CM4]= segment_Image(CN_4_M24_Reg,T1,T2);
[seg_CN_5_M24 CSF_CM5 GM_CM5 WM_CM5]= segment_Image(CN_5_M24_Reg,T1,T2);
[seg_CN_6_M24 CSF_CM6 GM_CM6 WM_CM6]= segment_Image(CN_6_M24_Reg,T1,T2);
[seg_CN_7_M24 CSF_CM7 GM_CM7 WM_CM7]= segment_Image(CN_7_M24_Reg,T1,T2);
[seg_CN_8_M24 CSF_CM8 GM_CM8 WM_CM8]= segment_Image(CN_8_M24_Reg,T1,T2);
[seg_CN_9_M24 CSF_CM9 GM_CM9 WM_CM9]= segment_Image(CN_9_M24_Reg,T1,T2);
[seg_CN_10_M24 CSF_CM10 GM_CM10 WM_CM10]= segment_Image(CN_10_M24_Reg,T1,T2);

figure('units','normalized','outerposition',[0 0 1 1]);
subplot(2,5,1);imshow(seg_AD_1_BL,[]);title('AD Baseline 1');
subplot(2,5,2);imshow(seg_AD_2_BL,[]);title('AD Baseline 2');
subplot(2,5,3);imshow(seg_AD_3_BL,[]);title('AD Baseline 3');
subplot(2,5,4);imshow(seg_AD_4_BL,[]);title('AD Baseline 4');
subplot(2,5,5);imshow(seg_AD_5_BL,[]);title('AD Baseline 5');
subplot(2,5,6);histogram(seg_AD_1_BL);title('Histogram AD BL 1');
subplot(2,5,7);histogram(seg_AD_2_BL);title('Histogram AD BL 2');
subplot(2,5,8);histogram(seg_AD_3_BL);title('Histogram AD BL 3');
subplot(2,5,9);histogram(seg_AD_4_BL);title('Histogram AD BL 4');
subplot(2,5,10);histogram(seg_AD_5_BL);title('Histogram AD BL 5');

figure('units','normalized','outerposition',[0 0 1 1]);
subplot(2,5,1);imshow(seg_AD_6_BL,[]);title('AD Baseline 6');
subplot(2,5,2);imshow(seg_AD_7_BL,[]);title('AD Baseline 7');
subplot(2,5,3);imshow(seg_AD_8_BL,[]);title('AD Baseline 8');
subplot(2,5,4);imshow(seg_AD_9_BL,[]);title('AD Baseline 9');
subplot(2,5,5);imshow(seg_AD_10_BL,[]);title('AD Baseline 10');
subplot(2,5,6);histogram(seg_AD_6_BL);title('Histogram AD BL 6');
subplot(2,5,7);histogram(seg_AD_7_BL);title('Histogram AD BL 7');
subplot(2,5,8);histogram(seg_AD_8_BL);title('Histogram AD BL 8');
subplot(2,5,9);histogram(seg_AD_9_BL);title('Histogram AD BL 9');
subplot(2,5,10);histogram(seg_AD_10_BL);title('Histogram AD BL 10');

figure('units','normalized','outerposition',[0 0 1 1]);
subplot(2,5,1);imshow(seg_AD_1_M24,[]);title('AD Follow Up 1');
subplot(2,5,2);imshow(seg_AD_2_M24,[]);title('AD Follow Up 2');
subplot(2,5,3);imshow(seg_AD_3_M24,[]);title('AD Follow Up 3');
subplot(2,5,4);imshow(seg_AD_4_M24,[]);title('AD Follow Up 4');
subplot(2,5,5);imshow(seg_AD_5_M24,[]);title('AD Follow Up 5');
subplot(2,5,6);histogram(seg_AD_1_M24);title('Histogram AD M24 1');
subplot(2,5,7);histogram(seg_AD_2_M24);title('Histogram AD M24 2');
subplot(2,5,8);histogram(seg_AD_3_M24);title('Histogram AD M24 3');
subplot(2,5,9);histogram(seg_AD_4_M24);title('Histogram AD M24 4');
subplot(2,5,10);histogram(seg_AD_5_M24);title('Histogram AD M24 5');

figure('units','normalized','outerposition',[0 0 1 1]);
subplot(2,5,1);imshow(seg_AD_6_M24,[]);title('AD Follow Up 6');
subplot(2,5,2);imshow(seg_AD_7_M24,[]);title('AD Follow Up 7');
subplot(2,5,3);imshow(seg_AD_8_M24,[]);title('AD Follow Up 8');
subplot(2,5,4);imshow(seg_AD_9_M24,[]);title('AD Follow Up 9');
subplot(2,5,5);imshow(seg_AD_10_M24,[]);title('AD Follow Up 10');
subplot(2,5,6);histogram(seg_AD_6_M24);title('Histogram AD M24 6');
subplot(2,5,7);histogram(seg_AD_7_M24);title('Histogram AD M24 7');
subplot(2,5,8);histogram(seg_AD_8_M24);title('Histogram AD M24 8');
subplot(2,5,9);histogram(seg_AD_9_M24);title('Histogram AD M24 9');
subplot(2,5,10);histogram(seg_AD_10_M24);title('Histogram AD M24 10');

figure('units','normalized','outerposition',[0 0 1 1]);
subplot(2,5,1);imshow(seg_CN_1_BL,[]);title('CN Baseline 1');
subplot(2,5,2);imshow(seg_CN_2_BL,[]);title('CN Baseline 2');
subplot(2,5,3);imshow(seg_CN_3_BL,[]);title('CN Baseline 3');
subplot(2,5,4);imshow(seg_CN_4_BL,[]);title('CN Baseline 4');
subplot(2,5,5);imshow(seg_CN_5_BL,[]);title('CN Baseline 5');
subplot(2,5,6);histogram(seg_CN_1_BL);title('Histogram CN BL 1');
subplot(2,5,7);histogram(seg_CN_2_BL);title('Histogram CN BL 2');
subplot(2,5,8);histogram(seg_CN_3_BL);title('Histogram CN BL 3');
subplot(2,5,9);histogram(seg_CN_4_BL);title('Histogram CN BL 4');
subplot(2,5,10);histogram(seg_CN_5_BL);title('Histogram CN BL 5');

figure('units','normalized','outerposition',[0 0 1 1]);
subplot(2,5,1);imshow(seg_CN_6_BL,[]);title('CN Baseline 6');
subplot(2,5,2);imshow(seg_CN_7_BL,[]);title('CN Baseline 7');
subplot(2,5,3);imshow(seg_CN_8_BL,[]);title('CN Baseline 8');
subplot(2,5,4);imshow(seg_CN_9_BL,[]);title('CN Baseline 9');
subplot(2,5,5);imshow(seg_CN_10_BL,[]);title('CN Baseline 10');
subplot(2,5,6);histogram(seg_CN_6_BL);title('Histogram CN BL 6');
subplot(2,5,7);histogram(seg_CN_7_BL);title('Histogram CN BL 7');
subplot(2,5,8);histogram(seg_CN_8_BL);title('Histogram CN BL 8');
subplot(2,5,9);histogram(seg_CN_9_BL);title('Histogram CN BL 9');
subplot(2,5,10);histogram(seg_CN_10_BL);title('Histogram CN BL 10');

figure('units','normalized','outerposition',[0 0 1 1]);
subplot(2,5,1);imshow(seg_CN_1_M24,[]);title('CN Follow Up 1');
subplot(2,5,2);imshow(seg_CN_2_M24,[]);title('CN Follow Up 2');
subplot(2,5,3);imshow(seg_CN_3_M24,[]);title('CN Follow Up 3');
subplot(2,5,4);imshow(seg_CN_4_M24,[]);title('CN Follow Up 4');
subplot(2,5,5);imshow(seg_CN_5_M24,[]);title('CN Follow Up 5');
subplot(2,5,6);histogram(seg_CN_1_M24);title('Histogram CN M24 1');
subplot(2,5,7);histogram(seg_CN_2_M24);title('Histogram CN M24 2');
subplot(2,5,8);histogram(seg_CN_3_M24);title('Histogram CN M24 3');
subplot(2,5,9);histogram(seg_CN_4_M24);title('Histogram CN M24 4');
subplot(2,5,10);histogram(seg_CN_5_M24);title('Histogram CN M24 5');

figure('units','normalized','outerposition',[0 0 1 1]);
subplot(2,5,1);imshow(seg_CN_6_M24,[]);title('CN Follow Up 6');
subplot(2,5,2);imshow(seg_CN_7_M24,[]);title('CN Follow Up 7');
subplot(2,5,3);imshow(seg_CN_8_M24,[]);title('CN Follow Up 8');
subplot(2,5,4);imshow(seg_CN_9_M24,[]);title('CN Follow Up 9');
subplot(2,5,5);imshow(seg_CN_10_M24,[]);title('CN Follow Up 10');
subplot(2,5,6);histogram(seg_CN_6_M24);title('Histogram CN M24 6');
subplot(2,5,7);histogram(seg_CN_7_M24);title('Histogram CN M24 7');
subplot(2,5,8);histogram(seg_CN_8_M24);title('Histogram CN M24 8');
subplot(2,5,9);histogram(seg_CN_9_M24);title('Histogram CN M24 9');
subplot(2,5,10);histogram(seg_CN_10_M24);title('Histogram CN M24 10');


%% MATLAB Comparison
Thres = multithresh(AD_5_BL,2);
MAT_AD_5_BL = imquantize(AD_5_BL,Thres);
Thres = multithresh(AD_5_M24_Reg,2);
MAT_AD_5_M24 = imquantize(AD_5_M24_Reg,Thres);
Thres = multithresh(CN_5_BL,2);
MAT_CN_5_BL = imquantize(CN_5_BL,Thres);
Thres = multithresh(CN_5_M24_Reg,2);
MAT_CN_5_M24 = imquantize(CN_5_M24_Reg,Thres);

figure('units','normalized','outerposition',[0 0 1 1]);
subplot(2,4,1);imshow(MAT_AD_5_BL,[]);title('AD Baseline 5');
subplot(2,4,2);imshow(seg_AD_5_BL,[]);title('MATLAB Func');
subplot(2,4,3);imshow(MAT_AD_5_M24,[]);title('AD Follow Up 5');
subplot(2,4,4);imshow(seg_AD_5_M24,[]);title('MATLAB Func');
subplot(2,4,5);imshow(MAT_CN_5_BL,[]); title('CN Baseline 5');
subplot(2,4,6);imshow(seg_CN_5_BL,[]); title('MATLAB Func');
subplot(2,4,7);imshow(seg_CN_5_M24,[]);title('CN Follow Up 5');
subplot(2,4,8);imshow(MAT_CN_5_M24,[]);title('MATLAB Func');
%% Calculating Different Tissue Matter

%Change in matter over time
y_1 = [CSF_B1 CSF_M1;CSF_B2 CSF_M2;CSF_B3 CSF_M3;CSF_B4 CSF_M4;CSF_B5 CSF_M5;CSF_B6 CSF_M6;CSF_B7 CSF_M7;CSF_B8 CSF_M8;CSF_B9 CSF_M9;CSF_B10 CSF_M10;];
y_2 = [CSF_CB1 CSF_CM1;CSF_CB2 CSF_CM2;CSF_CB3 CSF_CM3;CSF_CB4 CSF_CM4; CSF_CB5 CSF_CM5; CSF_CB6 CSF_CM6; CSF_CB7 CSF_CM7; CSF_CB8 CSF_CM8; CSF_CB9 CSF_CM9; CSF_CB10 CSF_CM10;];
y_3 = [GM_B1 GM_M1;GM_B2 GM_M2;GM_B3 GM_M3;GM_B4 GM_M4;GM_B5 GM_M5;GM_B6 GM_M6;GM_B7 GM_M7;GM_B8 GM_M8; GM_B9 GM_M9; GM_B10 GM_M10;];
y_4 = [GM_CB1 GM_CM1; GM_CB2 GM_CM2; GM_CB3 GM_CM3;GM_CB4 GM_CM4;GM_CB5 GM_CM5;GM_CB6 GM_CM6;GM_CB7 GM_CM7; GM_CB8 GM_CM8;GM_CB9 GM_CM9; GM_CB10 GM_CM10;];
y_5 = [WM_B1 WM_M1; WM_B2 WM_M2; WM_B3 WM_M3; WM_B4 WM_M4; WM_B5 WM_M5; WM_B6 WM_M6; WM_B7 WM_M7; WM_B8 WM_M8; WM_B9 WM_M9;WM_B10 WM_M10;];
y_6 = [WM_CB1 WM_CM1; WM_CB2 WM_CM2; WM_CB3 WM_CM3;WM_CB4 WM_CM4; WM_CB5 WM_CM5; WM_CB6 WM_CM6; WM_CB7 WM_CM7; WM_CB8 WM_CM8; WM_CB9 WM_CM9; WM_CB10 WM_CM10;];
x = [0 2];
figure('units','normalized','outerposition',[0 0 1 1]);
subplot(1,3,1); plot(x, y_1, 'red');title('CSF over Time'); xlabel('Time (years)'); ylabel('Volume (pixels)');hold on;plot(x, y_2, 'blue');
subplot(1,3,2); plot(x, y_3, 'red');title('Gray Matter over Time'); xlabel('Time (years)'); ylabel('Volume (pixels)'); hold on;plot(x, y_4, 'blue');
subplot(1,3,3); plot(x, y_5, 'red');title('White Matter over Time'); xlabel('Time (years)'); ylabel('Volume (pixels)'); hold on;plot(x, y_6, 'blue');

%Percentage change

x = [1:10];
percent_change_CSF_AD = calculate_percent_change(y_1);
percent_change_CSF_CN = calculate_percent_change(y_2);
percent_change_GM_AD = calculate_percent_change(y_3);
percent_change_GM_CN = calculate_percent_change(y_4);
percent_change_WM_AD = calculate_percent_change(y_5);
percent_change_WM_CN = calculate_percent_change(y_6);

figure('units','normalized','outerposition',[0 0 1 1]);
subplot(2,3,1);bar(x,percent_change_CSF_AD);title('Percent Change in CSF (AD)'); xlabel('AD Patient #'); ylabel('Percent Change');
subplot(2,3,2);bar(x,percent_change_CSF_CN);title('Percent Change in CSF (CN)'); xlabel('CN Patient #'); ylabel('Percent Change');
subplot(2,3,3);bar(x,percent_change_GM_AD);title('Percent Change in Gray Matter (AD)'); xlabel('AD Patient #'); ylabel('Percent Change');
subplot(2,3,4);bar(x,percent_change_GM_CN);title('Percent Change in Gray Matter (CN)'); xlabel('CN Patient #'); ylabel('Percent Change');
subplot(2,3,5);bar(x,percent_change_WM_AD);title('Percent Change in White Matter (AD)'); xlabel('AD Patient #'); ylabel('Percent Change');
subplot(2,3,6);bar(x,percent_change_WM_CN);title('Percent Change in White Matter (CN)'); xlabel('CN Patient #'); ylabel('Percent Change');

average_change_CSF_AD = sum(percent_change_CSF_AD)/10;
average_change_CSF_CN = sum(percent_change_CSF_CN)/10;
avarage_change_CSF = [average_change_CSF_AD average_change_CSF_CN];
average_change_GM_AD = sum(percent_change_GM_AD)/10;
average_change_GM_CN = sum(percent_change_GM_CN)/10;
avarage_change_GM = [average_change_GM_AD average_change_GM_CN];
average_change_WM_AD = sum(percent_change_WM_AD)/10;
average_change_WM_CN = sum(percent_change_WM_CN)/10;
avarage_change_WM = [average_change_WM_AD average_change_WM_CN];

x = categorical({'AD Patients','CN Patients'});
figure('units','normalized','outerposition',[0 0 1 1]);
subplot(1,3,1);bar(x,avarage_change_CSF);title('Average Percent Change in CSF');ylabel('Percent Change');
subplot(1,3,2);bar(x,avarage_change_GM);title('Average Percent Change in Gray Matter');ylabel('Percent Change');
subplot(1,3,3);bar(x,avarage_change_WM);title('Average Percent Change in White Matter');ylabel('Percent Change');

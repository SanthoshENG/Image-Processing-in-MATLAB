% Assignment 6: Fun With Masks
% Santhosh Nandakumar
% 301300261
% snandaku@sfu.ca
% Running this file will provide with all the outputs
% To see more detailed outlining of code please navigate to ./Deliverable
% directory where all outputs/code can be found
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NOTE All subplot titles do not run on other machines, however it works on
% my computer but I have commented it out just in case it does not run. For
% titles please look at the report
clear all;
close all
clc;
addpath('./Deliverables/Functions');
addpath('./Deliverables/Images');

grayEye = imread('./Deliverables/Images/myEye.jpg');
grayEye = rgb2gray(grayEye);
grayEye = mat2gray(grayEye);
%% Question 2 
%Setting up added noise
mean = 0.25;
variance = 0.05;
eyeGaussianNoise = imnoise(grayEye,'gaussian', mean, variance);

%Removing noise via different mask sizes
cMask5by5 = constantMask(eyeGaussianNoise,5);
cMask10by10 = constantMask(eyeGaussianNoise, 10);
cMask20by20 = constantMask(eyeGaussianNoise, 20);


figure('Name', ['Removing Gaussian Noise With Varying Mask Sizes'])
% Plot Original image
subplot (1,4,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(eyeGaussianNoise);
xlabel(['Eye With Noise']);

%Plot 5x5 mask results
subplot (1,4,2)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(cMask5by5);
xlabel(['Results of 5x5 mask']);

%Plot 10x10 mask results
subplot(1,4,3);
imshow(cMask10by10);
xlabel(['Results of 10x10 mask']);

%Plot 20x20 mask results
subplot (1,4,4);
imshow(cMask20by20)
xlabel(['Results of 20x20 mask']);
%suptitle(sprintf('Filtering Out Gaussian Noise With Varying Mask Size (Mean = %.2f Variance = %.2f)',mean, variance));

%% Question 3 Median Mask and Testing Different Cases
% Low density noise

d = 0.10;
eyeSaltPepperNoise = imnoise(grayEye,'salt & pepper',d);
spMask3by3 = medianMask(eyeSaltPepperNoise,3);
spMask5by5 = medianMask(eyeSaltPepperNoise,5);
spMask7by7 = medianMask(eyeSaltPepperNoise,7);



figure('Name', ['Removing Salt & Pepper Noise With Varying Mask Sizes'])
% Plot Original image
subplot (1,4,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(eyeSaltPepperNoise);
xlabel(['Eye With Salt & Pepper Noise']);

%Plot 3x3 mask results
subplot (1,4,2)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(spMask3by3);
xlabel(['Results of 3x3 mask']);

%Plot 5x5 mask results
subplot(1,4,3);
imshow(spMask5by5);
xlabel(['Results of 5x5 mask']);

%Plot 7x7 mask results
subplot (1,4,4);
imshow(spMask7by7)
xlabel(['Results of 7x7 mask']);
%suptitle(sprintf('Filtering Out Salt & Pepper Noise With Varying Mask Size (Low Density Noise d = %.2f)',d));

% High density noise

d = 0.5;
eyeSaltPepperNoise = imnoise(grayEye,'salt & pepper',d);
spMask3by3 = medianMask(eyeSaltPepperNoise,3);
spMask5by5 = medianMask(eyeSaltPepperNoise,5);
spMask7by7 = medianMask(eyeSaltPepperNoise,7);



figure('Name', ['Removing Salt & Pepper Noise With Varying Mask Sizes'])
% Plot Original image
subplot (1,4,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(eyeSaltPepperNoise);
xlabel(['Eye With Salt & Pepper Noise']);

% Plot 3x3 mask results
subplot (1,4,2)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(spMask3by3);
xlabel(['Results of 3x3 mask']);

%Plot 5x5 mask results
subplot(1,4,3);
imshow(spMask5by5);
xlabel(['Results of 5x5 mask']);

%Plot 7x7 mask results
subplot (1,4,4);
imshow(spMask7by7)
xlabel(['Results of 7x7 mask']);
%suptitle(sprintf('Filtering Out Salt & Pepper Noise With Varying Mask Size (High Density Noise d = %.2f)',d));


% Removing Salt & Pepper Noise with constantMask() 
d = 0.1;

cMask3by3 = constantMask(eyeSaltPepperNoise,3);
cMask5by5 = constantMask(eyeSaltPepperNoise, 5);
cMask7by7 = constantMask(eyeSaltPepperNoise, 7);

figure('Name', ['Removing Salt & Pepper Noise With constantMask()'])
% Plot Original image
subplot (1,4,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(eyeSaltPepperNoise);
xlabel(['Eye With Salt & Pepper Noise']);

% Plot 3x3 mask results
subplot (1,4,2)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(cMask3by3);
xlabel(['Results of 3x3 mask']);

%Plot 5x5 mask results
subplot(1,4,3);
imshow(cMask5by5);
xlabel(['Results of 5x5 mask']);

%Plot 7x7 mask results
subplot (1,4,4);
imshow(cMask7by7)
xlabel(['Results of 7x7 mask']);
%suptitle(sprintf('Filtering Out Salt & Pepper Noise With constantMask() (Noise Density d = %.2f)',d));

% Removing Gaussian Noise with medianMask() 

spMask3by3 = medianMask(eyeGaussianNoise,3);
spMask5by5 = medianMask(eyeGaussianNoise,5);
spMask7by7 = medianMask(eyeGaussianNoise,7);

figure('Name', ['Removing Gaussian Noise With medianMask()'])
% Plot Original image
subplot (1,4,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(eyeGaussianNoise);
xlabel(['Eye With Gaussian']);

%Plot 3x3 mask results
subplot (1,4,2)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(spMask3by3);
xlabel(['Results of 3x3 mask']);

%Plot 5x5 mask results
subplot(1,4,3);
imshow(spMask5by5);
xlabel(['Results of 5x5 mask']);

%Plot 7x7 mask results
subplot (1,4,4);
imshow(spMask7by7)
xlabel(['Results of 7x7 mask']);
%suptitle(sprintf('Filtering Out Gaussian With medianMask() (Mean = %.2f and Variance = %.2f)', mean, variance));

%% Question 4 Displaying Cos Function


M = 36; 
N = 48;

wx = 2*pi/M; 
wy = 2*pi/N;

[X,Y] = meshgrid(0:1:N-1, 0:1:M-1);

% case 1
u0 = 0; 
v0 = 0; 
case1Noise = cos(wx*u0*X + wy*v0*Y);
case1NoiseShift = cos(wx*u0*X + wy*v0*Y)+1;

% case 2
u0 = M/4; 
v0 = 0; 
case2Noise = cos(wx*u0*X + wy*v0*Y);
case2NoiseShift = cos(wx*u0*X + wy*v0*Y)+1;

% case 3
u0 = 0; 
v0 = N/2; 
case3Noise = cos(wx*u0*X + wy*v0*Y);
case3NoiseShift = cos(wx*u0*X + wy*v0*Y)+1;

% case 4
u0 = M/2; 
v0 = N/4; 
case4Noise = cos(wx*u0*X + wy*v0*Y);
case4NoiseShift = cos(wx*u0*X + wy*v0*Y)+1;


figure('Name', ['Cosine Function'])
% Plot Case 1
subplot (2,4,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(case1Noise, []);
xlabel(['u_0 = 0    v_0 = 0']);

%Plot Case 2
subplot (2,4,2)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(case2Noise, []);
xlabel(['u_0 = M/4    v_0 = 0']);

%Plot Case 3
subplot(2,4,3);
imshow(case3Noise, []);
xlabel(['u_0 = 0    v_0 = N/2']);

%Plot Case 4
subplot (2,4,4);
imshow(case4Noise, []);
xlabel(['u_0 = M/4    v_0 = N/2']);

% Plot Case 1 Shiftted 
subplot (2,4,5)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(case1NoiseShift, []);
xlabel(['u_0 = 0    v_0 = 0 (Shifted)']);

%Plot Case 2 Shiffted
subplot (2,4,6)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(case2NoiseShift, []);
xlabel(['u_0 = M/4    v_0 = 0 (Shifted)']);

%Plot Case 3 Shiffted
subplot(2,4,7);
imshow(case3NoiseShift, []);
xlabel(['u_0 = 0    v_0 = N/2 (Shifted)']);

%Plot Case 4 Shiffted
subplot (2,4,8);
imshow(case4NoiseShift, []);
xlabel(['u_0 = M/4    v_0 = N/2 (Shifted)']);
%suptitle(sprintf('Cosine Function (M = %.0f N = %.0f)', M,N));

%% Question 5 Rect Function

M = 36;
N = 48;
inner = 255*ones(round(M/2),round(N/2));
rect = padarray(inner,[round(M/4) round(N/4)],0,'both');

figure('Name', ['Rect Function Displayed as an Image']);
imshow(rect);
title(sprintf('Rect Function %.0f by %.0f', M,N));

%% Question 6 FFT of Cos and Rect Functions


fftRect = fft2(rect);

% FFTs Not Shifted Cosines
fftCos1 = fft2(case1Noise);
fftCos2 = fft2(case2Noise);
fftCos3 = fft2(case3Noise);
fftCos4 = fft2(case4Noise);

% FFTs Shifted Cosine
fftCos1Shifted = fft2(case1NoiseShift);
fftCos2Shifted = fft2(case2NoiseShift);
fftCos3Shifted = fft2(case3NoiseShift);
fftCos4Shifted = fft2(case4NoiseShift);


figure('Name', ['FFT of Rect Function']);
subplot(1,2,1)
imshow(fftRect);
title(sprintf('FFT of Rect Function %.0f by %.0f', M,N));

subplot(1,2,2)
imshow(log(fftRect));
title(sprintf('Log scaled FFT of Rect Function %.0f by %.0f', M,N));


figure('Name', ['FFT Cosine Function'])
% Plot Case 1
subplot (2,4,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(fftCos1);
title(['u_0 = 0    v_0 = 0']);
xlabel(['U frequency']);
ylabel(['V frequency']);

%Plot Case 2
subplot (2,4,2)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(fftCos2);
title(['u_0 = M/4    v_0 = 0']);
xlabel(['U frequency']);
ylabel(['V frequency']);

%Plot Case 3
subplot(2,4,3);
imshow(fftCos3);
title(['u_0 = 0    v_0 = N/2']);
xlabel(['U frequency']);
ylabel(['V frequency']);

%Plot Case 4
subplot (2,4,4);
imshow(fftCos4);
title(['u_0 = M/4    v_0 = N/2']);
xlabel(['U frequency']);
ylabel(['V frequency']);

% Plot Case 1 Shifted 
subplot (2,4,5)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(fftCos1Shifted);
title(['u_0 = 0    v_0 = 0 (Shifted)']);
xlabel(['U frequency']);
ylabel(['V frequency']);

%Plot Case 2 Shifted
subplot (2,4,6)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(fftCos2Shifted);
title(['u_0 = M/4    v_0 = 0 (Shifted)']);
xlabel(['U frequency']);
ylabel(['V frequency']);

%Plot Case 3 Shifted
subplot(2,4,7);
imshow(fftCos3Shifted);
title(['u_0 = 0    v_0 = N/2 (Shifted)']);
xlabel(['U frequency']);
ylabel(['V frequency']);

%Plot Case 4 Shifted
subplot (2,4,8);
imshow(fftCos4Shifted);
title(['u_0 = M/4    v_0 = N/2 (Shifted)']);
xlabel(['U frequency']);
ylabel(['V frequency']);
%suptitle(sprintf('FFT of Cosine Function (M = %.0f N = %.0f)', M,N));

%% Question 7 FFTSHIFT of Cos and Rect Functions

shiftRect = fftshift(fftRect);
shift1 = fftshift(fftCos1);
shift2 = fftshift(fftCos2);
shift3 = fftshift(fftCos3);
shift4 = fftshift(fftCos4);
shift5 = fftshift(fftCos1Shifted);
shift6 = fftshift(fftCos2Shifted);
shift7 = fftshift(fftCos3Shifted);
shift8 = fftshift(fftCos4Shifted);


figure('Name', ['FFT of Rect Function']);
subplot(1,2,1)
imshow(shiftRect);
title(sprintf('Centered FFT of Rect Function'));
xlabel(sprintf('%.0f by %.0f', M,N));
subplot(1,2,2)
imshow(log(shiftRect));
title(sprintf('Centered Log scaled FFT of Rect Function'));
xlabel(sprintf('%.0f by %.0f', M,N));

figure('Name', ['Shifted FFT Cosine Function'])
% Plot Case 1
subplot (2,4,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(shift1);
title(['u_0 = 0    v_0 = 0']);
xlabel(['U frequency']);
ylabel(['V frequency']);

%Plot Case 2
subplot (2,4,2)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(shift2);
title(['u_0 = M/4    v_0 = 0']);
xlabel(['U frequency']);
ylabel(['V frequency']);

%Plot Case 3
subplot(2,4,3);
imshow(shift3);
title(['u_0 = 0    v_0 = N/2']);
xlabel(['U frequency']);
ylabel(['V frequency']);

%Plot Case 4
subplot (2,4,4);
imshow(shift4);
title(['u_0 = M/4    v_0 = N/2']);
xlabel(['U frequency']);
ylabel(['V frequency']);

% Plot Case 1 Shifted 
subplot (2,4,5)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(shift5);
title(['u_0 = 0    v_0 = 0']);
xlabel(['U frequency']);
ylabel(['V frequency']);

%Plot Case 2 Shifted
subplot (2,4,6)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(shift6);
title(['u_0 = M/4    v_0 = 0']);
xlabel(['U frequency']);
ylabel(['V frequency']);

%Plot Case 3 Shifted
subplot(2,4,7);
imshow(shift7);
title(['u_0 = 0    v_0 = N/2']);
xlabel(['U frequency']);
ylabel(['V frequency']);

%Plot Case 4 Shifted
subplot (2,4,8);
imshow(shift8);
title(['u_0 = M/4    v_0 = N/2']);
xlabel(['U frequency']);
ylabel(['V frequency']);
%suptitle(sprintf('Centered Cosine Function (M = %.0f N = %.0f)', M,N));

%% Question 8 Ideal Low Pass Filter
idealLPF = lowPassFilter(ones(5*M,4*N), 2*M,3*N);
idealLPF = padarray( idealLPF,[round(M) round(N)],0,'both');

figure('Name', ['Low Pass Filter Displayed as an Image']);
imshow(idealLPF);
title(['Low Pass Filter as an Image']);


%% Question 9 Low Pass Filter

lpfTimeDomainLess = lowPassFilter(grayEye,20,50);

lpfTimeDomainMore = lowPassFilter(grayEye,100,120);

%Plot LPF 
figure('Name', ['Eye Image after Low Pass Filtering'])
subplot (1,3,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(grayEye);
xlabel(['Original Eye']);

%Plot LPF fewer frequncies passed 
subplot (1,3,2)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(mat2gray(lpfTimeDomainLess));
xlabel(['Low Pass Filtering (Fewer Frequencies Passed)']);

%Plot LPF more frequncies passed
subplot (1,3,3)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(mat2gray(lpfTimeDomainMore));
xlabel(['Low Pass Filtering (More Frequencies Passed)']);

%suptitle('Eye Image After Low Pass Filtering');

%% Question 10 High Pass Filter

hpfTimeDomainLess = highPassFilter(grayEye,20,40);
hpfTimeDomainMore = highPassFilter(grayEye,154,270);

figure('Name', ['Eye Image after High Pass Filtering'])
subplot (1,3,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(grayEye);
xlabel(['Original Eye']);

%Plot Rect Function
subplot (1,3,2)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(hpfTimeDomainLess, []);
xlabel(['High Pass Filtering (Fewer Frequencies Passed)']);

%Plot Rect Function
subplot (1,3,3)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(hpfTimeDomainMore, []);
xlabel(['High Pass Filtering (More Frequencies Passed)']);

suptitle('Eye Image After High Pass Filtering');


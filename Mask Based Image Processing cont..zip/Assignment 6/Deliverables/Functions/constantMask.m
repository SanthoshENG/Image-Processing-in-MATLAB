function filteredImage = constantMask(image,maskSize)

% Input Arguments:
%                *image: image matrix that will be padded
%                *maskSize: size of the mask (must be a positive integer)
% Output Arguements:
%                  *filteredImage: returns the smoothed original image. In
%                  this application an image containing Gaussian noise is
%                  passed in. The output will reduce noise through
%                  smoothing.                          


%Predetermined filtered image size which matches the original input image
filteredImage = zeros(size(image));

%Sets padding based on the mask size 
%Different for even and odd cases of mask size
if mod(maskSize,2) == 1
    image = padarray(image,[floor(maskSize/2) floor(maskSize/2)],0,'both');
else
    image = padarray(image,[floor(maskSize/2)-1 floor(maskSize/2)-1],0,'both');
end

%Normalized component which helps to smooth
[numRows numCols] = size(image); 
c = 1/(maskSize^2);
mask = c*ones(maskSize, maskSize);

%2 for loops used
%First loop is entered if mask is odd
%Second loop is entered if mask is even
if mod(maskSize,2) == 1
    for i = (ceil(maskSize/2)):(numRows-floor(maskSize/2))
        for j = (ceil(maskSize/2)):(numCols-floor(maskSize/2))
         filteredImage(i-(floor(maskSize/2)),j-(floor(maskSize/2))) = ...
            sum(sum(mask.*image(i-floor(maskSize/2):i+floor(maskSize/2),...
            j-floor(maskSize/2):j+floor(maskSize/2))));
        end
    end
else
    for i = (ceil(maskSize/2)):(numRows-floor(maskSize/2))
        for j = (ceil(maskSize/2)):(numCols-floor(maskSize/2))
         filteredImage(i-(floor(maskSize/2))+1,j-(floor(maskSize/2))+1) = ...
            sum(sum(mask.*image(i-floor(maskSize/2)+1:i+floor(maskSize/2),...
            j-floor(maskSize/2)+1:j+floor(maskSize/2))));
        end
    end
end

end
                 
                 

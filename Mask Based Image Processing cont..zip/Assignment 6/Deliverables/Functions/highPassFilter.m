function finalTDomain = highPassFilter(image, height, width)
% Input Arguments:
%                *image: image matrix that will be high pass filter
%                *height: height of filter (number of rows)
%                *width: width of of filter (number of columns)
% Output Arguements:
%                  *finalTDomain: returns the final image after
%                   low frequencies are removed based on provided filter
%                   filtered specifications



[rows cols] = size(image);
%Checks if filter specifications are within the range of the image
if height > rows
    printf('height of LPF exceeds image dimensions');
elseif width > cols
    printf('width of LPF exceeds image dimensions');
else
    A = rows - height;
    B = cols - width;
    idealHPF = padarray( ones(height,width),[round(A/2) round(B/2)],0,'both');
end
%Compensated for rounding error to ensure matrix dimensions agree
if mod(A,2)==1 && mod(B,2) == 1
    image = padarray(image,[1,1],0,'both');
elseif mod(A,2) == 1
    image = padarray(image,[1,0],0,'post');
elseif mod(B,2) == 1
    image = padarray(image,[0,1],0,'post');
else
    fftImage = fft2(image);
    hpfFDomain = fftImage.*idealHPF;
    finalTDomain = abs(ifft2(hpfFDomain));
end
%Preforms fourier transform and filtering out of high frequencies
    fftImage = fft2(image);
    hpfFDomain = fftImage.*idealHPF;
    finalTDomain = abs(ifft2(hpfFDomain));
end
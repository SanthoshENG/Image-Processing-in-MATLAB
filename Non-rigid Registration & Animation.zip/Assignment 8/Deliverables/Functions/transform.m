function [transformed_image] = transform(template_image, dispField_x, dispField_y)

% Input Arguments:
%                *template_image: image to be tranformed
%                *dispField_x: displacement in the x direction of each pixel
%                of the image, returns a matrix the size of the image
%                *dispField_y: displacement in the y direction of each pixel of
%                the image, returns a matrix the size of the image 
% Output Arguements:
%                *transformed_image = image matrix after transformation

[rows cols] = size(template_image);
transformed_image = zeros(rows,cols);
for i = 1:rows %y
    for j = 1:cols %x
        transformed_image(i,j) = template_image(round(i-dispField_y(i,j)),round(j-dispField_x(i,j)));
    end
end

end

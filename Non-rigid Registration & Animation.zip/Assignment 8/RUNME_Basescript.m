%%
% Assignment 8: Non-rigid Registration
% Santhosh Nandakumar
% 301300261
% snandaku@sfu.ca
% Running this file will provide with all the outputs
% To see more detailed outlining of code please navigate to ./Deliverables
% directory where all outputs/code can be found
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;
close all
clc;
addpath('./Deliverables/Functions');
addpath('./Deliverables/Images');

template = imread('./Deliverables/Images/template.jpg');
target = imread('./Deliverables/Images/target.jpg');

template = mat2gray(rgb2gray(template));
target = mat2gray(rgb2gray(target));

[rows cols] = size(template);

%cpselect(template, target);
%template and smile 
template_cols = [144.25 158.75 175.75 192.25 208.25 224.75 237.25];
template_rows = [355.75 351.25 351.25 350.25 349.25 353.25 355.25];
target_cols = [134.75 145.75 170.75 193.75 216.75 238.75 247.25];
target_rows = [321.75 333.75 341.75 344.25 337.25 330.25 318.75];

%% 1.1) Estimating Transformation phi(x) and phi inverse

%Displacement fields for different values of sigma
%Sigma = 1
[d_x d_y] = dispField(rows,cols,template_cols,template_rows,target_cols,target_rows,1);
%Sigma = 5
[d_x_1 d_y_1] = dispField(rows,cols,template_cols,template_rows,target_cols,target_rows,5);
%Sigma = 15
[d_x_2 d_y_2] = dispField(rows,cols,template_cols,template_rows,target_cols,target_rows,15);


%figure('units','normalized','outerposition',[0 0 1 1]);
figure;
subplot (1,3,1)
quiver(d_x,d_y)
set(gca,'ydir','reverse');
xlim([125,250])
ylim([346,358])
set(gcf, 'Position', get(0, 'Screensize'));
title('u(x) sigma = 1')
xlabel('X (columns)')
ylabel('Y (rows)')

subplot (1,3,2)
set(gcf, 'Position', get(0, 'Screensize'));
quiver(d_x_1,d_y_1)
set(gca,'ydir','reverse');
xlim([125,250])
ylim([330,370])
title('u(x) sigma = 5')
xlabel('X (columns)')
ylabel('Y (rows)')

subplot (1,3,3)
set(gcf, 'Position', get(0, 'Screensize'));
quiver(d_x_2,d_y_2)
set(gca,'ydir','reverse');
xlim([75,300])
ylim([290,410])
title('u(x) sigma = 15')
xlabel('X (columns)')
ylabel('Y (rows)')

figure('units','normalized','outerposition',[0 0 1 1]);
%figure;
subplot (1,2,1)
quiver(d_x_1,d_y_1)
set(gca,'ydir','reverse');
xlim([125,255])
ylim([335,375])
title('Displacement field "u(x)"')
xlabel('X (columns)')
ylabel('Y (rows)')

subplot (1,2,2)
quiver(-1*d_x_1,-1*d_y_1)
set(gca,'ydir','reverse');
xlim([125,255])
ylim([335,375])
title('Inverse of Displacement field "-u(x)"')
xlabel('X (columns)')
ylabel('Y (rows)')

[X Y] = meshgrid(1:cols, 1:rows);

%Finding phi and phi inverse
x = 1:cols;
y = 1:rows;

phi_x = X + d_x_1;
phi_y = Y + d_y_1;

inv_phi_x = X - d_x_1;
inv_phi_y = Y - d_y_1;


figure('units','normalized','outerposition',[0 0 1 1]);
%figure;
subplot(1,2,1)
plot(phi_x,phi_y)
xlim([1,cols]);
ylim([1,rows]);
title('\bf\phi\it(x) for Forward Transformation')
xlabel('X (columns)')
ylabel('Y (rows)')
set(gca,'ydir','reverse');

subplot(1,2,2)
plot(inv_phi_x,inv_phi_y)
xlim([1,cols]);
ylim([1,rows]);
title('\bf\phi^{-1}\it(x), Inverse Transformation')
xlabel('X (columns)')
ylabel('Y (rows)')
set(gca,'ydir','reverse');

%% 1.2) Applying phi(x)

%Transform non-smile image (template) image to smile image (target)
template_to_target = transform(template, d_x_2, d_y_2);

%Transform smile image (target) image to non-smile image (template)
target_to_template = transform(target, (-1*d_x_2), (-1*d_y_2));

figure;
subplot (1,2,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(template)
title('Template Image to Target Image')

subplot (1,2,2)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(template_to_target)
title('Template Image to Target Image')

figure;
subplot (1,2,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(target)
title('Template Image to Target Image')

subplot (1,2,2)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(target_to_template)
title('Target Image to Template Image')

%% 2.1) Making the Template Image frown

%To find frown points
%cpselect(template, template);

%frown points
template_cols = [187.75 142.25 166.75 220.25 239.75 130.75 258.25];
template_rows = [351.25 352.75 350.75 352.25 353.25 357.25 354.75];
frown_cols = [189.75 124.25 153.75 227.25 256.25 110.75 258.25];
frown_rows = [353.25 366.25 354.25 357.75 374.75 380.25 395.25];

%Displacement field for frown image
%Sigma = 1
[d_x d_y] = dispField(rows,cols,template_cols,template_rows,frown_cols,frown_rows,1);
%Sigma = 5
[d_x_1 d_y_1] = dispField(rows,cols,template_cols,template_rows,frown_cols,frown_rows,5);
%Sigma = 15
[d_x_2 d_y_2] = dispField(rows,cols,template_cols,template_rows,frown_cols,frown_rows,15);

%figure('units','normalized','outerposition',[0 0 1 1]);
figure;
subplot (1,3,1)
quiver(d_x,d_y)
set(gca,'ydir','reverse');
xlim([115,275])
ylim([346,362])
set(gcf, 'Position', get(0, 'Screensize'));
title('u(x) sigma = 1')
xlabel('X (columns)')
ylabel('Y (rows)')

subplot (1,3,2)
set(gcf, 'Position', get(0, 'Screensize'));
quiver(d_x_1,d_y_1)
set(gca,'ydir','reverse');
xlim([100,285])
ylim([330,390])
title('u(x) sigma = 5')
xlabel('X (columns)')
ylabel('Y (rows)')

subplot (1,3,3)
set(gcf, 'Position', get(0, 'Screensize'));
quiver(d_x_2,d_y_2)
set(gca,'ydir','reverse');
xlim([75,300])
ylim([290,410])
title('u(x) sigma = 15')
xlabel('X (columns)')
ylabel('Y (rows)')


figure('units','normalized','outerposition',[0 0 1 1]);
%figure;
subplot (1,2,1)
quiver(d_x_1,d_y_1)
set(gca,'ydir','reverse');
xlim([100,310])
ylim([330,380])
title('Displacement field "u(x)"')
xlabel('X (columns)')
ylabel('Y (rows)')

subplot (1,2,2)
quiver(-1*d_x_1,-1*d_y_1)
set(gca,'ydir','reverse');
xlim([100,310])
ylim([330,380])
title('Inverse of Displacement field "-u(x)"')
xlabel('X (columns)')
ylabel('Y (rows)')

[X Y] = meshgrid(1:cols, 1:rows);

%Finding phi and phi inverse
x = 1:cols;
y = 1:rows;
phi_x = X + d_x_1;
phi_y = Y + d_y_1;

inv_phi_x = X - d_x_1;
inv_phi_y = Y - d_y_1;


figure('units','normalized','outerposition',[0 0 1 1]);
%figure;
subplot(1,2,1)
plot(phi_x,phi_y)
xlim([1,cols]);
ylim([1,rows]);
title('\bf\phi\it(x) for Forward Transformation')
xlabel('X (columns)')
ylabel('Y (rows)')
set(gca,'ydir','reverse');

subplot(1,2,2)
plot(inv_phi_x,inv_phi_y)
xlim([1,cols]);
ylim([1,rows]);
title('\bf\phi^{-1}\it(x), Inverse Transformation')
xlabel('X (columns)')
ylabel('Y (rows)')
set(gca,'ydir','reverse');

%% 2.2) Template to Frown

template_to_frown = transform(template, d_x_2, d_y_2);

figure;
subplot (1,2,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(template)
title('Template Image to Target Image')

subplot (1,2,2)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(template_to_frown)
title('Template Image to Target Image')

%% 3) Animation of question 2 with Gif 

figure;

filename = 'template_to_frown.gif'; % output file name

for i = 1:0.025:2
    c = i-1;
    template_to_frown = transform(template, c*d_x_2, c*d_y_2);
    imshow(template_to_frown);
    f = getframe();
    [A,map] = rgb2ind(f.cdata,256,'nodither');
    if i == 1
        imwrite(A,map,filename,'gif','LoopCount',Inf,'DelayTime',0.001);
    else
        imwrite(A,map,filename,'gif','WriteMode','append','DelayTime',0.001);
    end    
end


figure;
subplot (2,3,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(template)
xlabel('frame 1')

subplot (2,3,2)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(transform(template, 0.2*d_x_2, 0.2*d_y_2))
title('Template Image to Frown Image')
xlabel('frame 8')

subplot (2,3,3)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(transform(template, 0.4*d_x_2, 0.4*d_y_2))
xlabel('frame 16')

subplot (2,3,4)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(transform(template, 0.6*d_x_2, 0.6*d_y_2))
xlabel('frame 24')

subplot (2,3,5)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(transform(template, 0.8*d_x_2, 0.8*d_y_2))
xlabel('frame 32')

subplot (2,3,6)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(transform(template, d_x_2, d_y_2))
xlabel('frame 40')



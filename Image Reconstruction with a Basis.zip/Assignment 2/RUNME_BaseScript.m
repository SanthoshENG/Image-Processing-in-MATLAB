% Assignment 2: Reconstruction in a basis
% Santhosh Nandakumar
% 301300261
% snandaku@sfu.ca
% Running this file will provide with all the outputs
% To see more detailed outlining of code please navigate to ./Deliverable
% directory where all outputs/code can be found



clear all;
close all
clc;
addpath('./Deliverables/Question1');
addpath('./Deliverables/Question2');
addpath('./Deliverables/Question3');
addpath('./Deliverables/Question4');
addpath('./Deliverables/Functions');

%Question 1

displayQ1()

%Question 2

displayQ2()

%Question 3

displayQ3()

%Question 4

displayQ4()
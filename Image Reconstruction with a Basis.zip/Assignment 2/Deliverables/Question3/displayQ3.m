function displayQ3()

%setting up column vectors given in question
%c_1, c_2, c_3 will make up matrix A (5X3) of Ax = b
% and b will be the column that is reconstructed
c_1 = [1 1 1 1 1]';
c_2 = [1 2 3 4 5]';
c_3 = [3 7 4 6 2]';
b = [1 0 1 0 1]';

%function call to reconstructBasis will return 
%coordinate values alpha and beta
%reconstructed vector b
[coords, b_reconstruct] = reconstructBasis(b, c_1, c_2, c_3);
distance = norm(b_reconstruct - b);

%allows alpha,beta and gamma to be printed nicely
alpha = char(945);
beta = char(946);
gamma = char(947);

fprintf('<Question 3>\n\n');
fprintf('Using the following coordinates the reconstruction of b is shown below \n\n');
fprintf('%s = %f', alpha, coords(1));
fprintf('    %s = %f', beta, coords(2));
fprintf('       %s = %f \n\n', gamma, coords(3));
disp(['b_reconstruct = ' mat2str(b_reconstruct',2)]);
fprintf('\nThe distance between b and the reconstruction of b is \n\n    %f \n', distance);
fprintf('__________________________________________________________________________\n');


end
function displayQ4()

%convert all required images into an RGB matrix then converting to gray scale
% ***imcrop is used to crop face images to ensure only the face is showing

faceImage = RGBtoGrayScale('./Deliverables/Images/myMugShot.jpg');
faceImage = imcrop(faceImage,[125 265 370 460]);

nonFaceImage = RGBtoGrayScale('./Deliverables/Images/nonFaceImage.jpg');

faceImage_I = RGBtoGrayScale('./Deliverables/Images/faceImage_I.jpg');
faceImage_I = imcrop(faceImage_I,[125 265 370 460]);

otherImage_1 = RGBtoGrayScale('./Deliverables/Images/other1.jpg');
otherImage_2 = RGBtoGrayScale('./Deliverables/Images/other2.jpg');
otherImage_3 = RGBtoGrayScale('./Deliverables/Images/other3.jpg');

%convert all matrices into column vectors to perform computation
c_faceImage = faceImage(:);
c_nonFaceImage = nonFaceImage(:);
c_faceImage_I = faceImage_I(:);
c_otherImage_1 = otherImage_1(:);
c_otherImage_2 = otherImage_2(:);
c_otherImage_3 = otherImage_3(:);

%%%%%%%%%%%%%%%%% 4.1 %%%%%%%%%%%%%%%%%

%computes the vector projection of myMugShot onto nonFaceImage
vectorProjection = (dot(c_faceImage,c_nonFaceImage)/(abs((norm(c_nonFaceImage))))^2)*(c_nonFaceImage);

%rehapes/resizes column vector into the same size as nonFaceImage
projection = reshape(vectorProjection,size(nonFaceImage));

% using the min and max arguements in imshow() provides greater contrast 
% to be seen in the output image
fprintf('<Question 4>\n\n');
fprintf('4.1) See Figure_Question4_1 for vector projection of Face Image onto Non-Face Image\n');
figure('name', 'Figure_Question4_1');
imshow(projection,[min(projection(:)), max(projection(:))]);
title('Face Image projected onto Non-Face Image');

%%%%%%%%%%%%%%%%% 4.2 %%%%%%%%%%%%%%%%%
%Simple condition statement to check whether two images are orthogonal
%The definition being that the dot product of two orthogonal vectors is 0
if(dot(c_faceImage,c_nonFaceImage)== 0)
    fprintf('\n4.2) The face image and non-face image are orthogonal\n');
else
    fprintf('\n4.2) The face image and non-face image are NOT orthogonal\n\n');
end

%%%%%%%%%%%%%% 4.3 - 4.5 %%%%%%%%%%%%%%
%function call to reconstructBasis will return 
%   *coordinate values alpha and beta
%   *reconstructed image as column vector 
%reshape function is used to reshape it the 
%conventional MXN matrix to be displayed
[coords, I_reconstruct] = reconstructBasis(c_faceImage_I, c_faceImage, c_nonFaceImage);
I_reconstruct = reshape(I_reconstruct,size(faceImage_I));

%Outputs one figure with both original and reconstructed image 
figure('name','Figure_Question4_5')
subplot(1,2,1);
imshow( faceImage_I, [min(faceImage_I(:)), max(faceImage_I(:))]);
title('Original Image "I"');
subplot(1,2,2);
imshow(I_reconstruct,[min(I_reconstruct(:)), max(I_reconstruct(:))]);
title('Reconstruction of "I"');
xlabel([char(945) '=' num2str(coords(1),2) '  ' char(946) '=' num2str(coords(2),2)]);

alpha = char(945);
beta = char(946);

%Prints out alpha and beta values of the reconstruction
fprintf('4.3-4.5) The coordinates used in the reconstruction are given below\n')
fprintf('%s = %f', alpha, coords(1));
fprintf('    %s = %f \n\n', beta, coords(2));

%%%%%%%%%%%%%%%%% 4.6 %%%%%%%%%%%%%%%%%
%More examples of reconstructing an image with a basis are given

%Example 1
[coords1, other1_reconstruct] = reconstructBasis(c_otherImage_1, c_faceImage, c_nonFaceImage);
other1_reconstruct = reshape(other1_reconstruct,size(otherImage_1));

figure('name','Figure_Question4_6 Example 1')
subplot(1,2,1);
imshow( otherImage_1, [min(otherImage_1(:)), max(otherImage_1(:))]);
title('Original Image "I"');
subplot(1,2,2);
imshow(other1_reconstruct,[min(other1_reconstruct(:)), max(other1_reconstruct(:))])
title('Reconstruction of Image "I"')
xlabel([char(945) '=' num2str(coords1(1),2) '  ' char(946) '=' num2str(coords1(2),2)])

fprintf('4.6) The coordinates used in the reconstruction of example 1\n')
fprintf('%s = %f', alpha, coords1(1));
fprintf('    %s = %f \n\n', beta, coords1(2));

%Example 2
[coords2, other2_reconstruct] = reconstructBasis(c_otherImage_2, c_faceImage, c_nonFaceImage);
other2_reconstruct = reshape(other2_reconstruct,size(otherImage_2));

figure('name','Figure_Question4_6 Example 2')
subplot(1,2,1);
imshow( otherImage_2, [min(otherImage_2(:)), max(otherImage_2(:))]);
title('Original Image "I"');
subplot(1,2,2);
imshow(other2_reconstruct,[min(other2_reconstruct(:)), max(other2_reconstruct(:))])
title('Reconstruction of Image "I"')
xlabel([char(945) '=' num2str(coords2(1),2) '  ' char(946) '=' num2str(coords2(2),2)])

fprintf('The coordinates used in the reconstruction of example 2\n')
fprintf('%s = %f', alpha, coords2(1));
fprintf('    %s = %f \n\n', beta, coords2(2));

%Example 3
[coords3, other3_reconstruct] = reconstructBasis(c_otherImage_3, c_faceImage, c_nonFaceImage);
other3_reconstruct = reshape(other3_reconstruct,size(otherImage_3));

figure('name','Figure_Question4_6 Example 3')
subplot(1,2,1);
imshow( otherImage_3, [min(otherImage_3(:)), max(otherImage_3(:))]);
title('Original Image "I"');
subplot(1,2,2);
imshow(other3_reconstruct,[min(other3_reconstruct(:)), max(other3_reconstruct(:))])
title('Reconstruction of Image "I"')
xlabel([char(945) '=' num2str(coords3(1),2) '  ' char(946) '=' num2str(coords3(2),2)])

fprintf('The coordinates used in the reconstruction of example 3\n')
fprintf('%s = %f', alpha, coords3(1));
fprintf('    %s = %f \n\n', beta, coords3(2));

end




function displayQ1()

%Matlab solves equation assuming an arbitrary 
%constant for the initial condition
syms y(t) x w
x = exp(i*w*t);
ode = 2*diff(y,t)+ 3*y == 4*x;
solution = dsolve(ode);

fprintf('<Question 1>\n\n');
fprintf('The solution to the differential equation is: \n\n y(t) = ');
disp(solution);
fprintf('\nThis solution assumes an arbitrary constant for the initial condition\n');
fprintf('\nThe solution shown in the Assignment 2 report assumes that all initial conditions are zero\n');
fprintf('__________________________________________________________________________\n');

end
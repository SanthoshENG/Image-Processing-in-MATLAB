function [GrayScale]= RGBtoGrayScale(filename) 

originalImage = imageToRGB(filename);    %converts and stores the image as an RGB 3D matrix 
originalImage = double(originalImage);   %convert to double to mantain precision and detail

R = originalImage(:,:,1);   %extracts R matrix
G = originalImage(:,:,2);   %extracts G matrix
B = originalImage(:,:,3);   %extracts B matrix

averageRGB = (R+G+B)/3;     %produces the overall gray scale image

GrayScale = mat2gray(averageRGB); %uint8 converts the gray scale image back into an 8 bit unsigned integer

end
function [ coords, b_reconstruct] = reconstructBasis(b, varargin)
%Reconstructs the desired column vector b in terms of the given basis 
%vectors, c_1, c_2, ..., c_n 
%   Returns: 
%           coords: the coordinates used in the reconstruction of b
%           b_reconstruct: the reconstructed vector itself

numberOfBasis = nargin;

% creating the matrix A = [c_1 c_2 c_3...]
matrixA=[];

for i=1:(numberOfBasis - 1)
    matrixA = [matrixA varargin{i}];
end

% Solves Ax=b for x using least square minimization method, 
% where x will be the required coordinates for the basis reconstruction
coords = (matrixA'*matrixA)^-1*matrixA' *b; 
% Reshapes/resizes b_reconstruct to the same size as the orignal vector b
b_reconstruct = reshape(matrixA*coords,size(b)); 
end
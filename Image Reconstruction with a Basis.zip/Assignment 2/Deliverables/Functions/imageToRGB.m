function [RGBMatrix] = imageToRGB(filename)

[RGBMatrix] = imread(filename); %imread() converts image into 3D RGB matrix 
                                %returns 3D matrix of R G and B

end
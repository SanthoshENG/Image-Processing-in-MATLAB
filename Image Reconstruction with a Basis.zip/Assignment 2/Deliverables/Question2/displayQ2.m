function displayQ2()

%setting up column vectors given in question
%c_1 and c_2 will make up matrix A (5X2) of Ax = b
% and b will be the column that is reconstructed
c_1 = [1 1 1 1 1]';
c_2 = [1 2 3 4 5]';
b = [1 0 1 0 1]';

%function call to reconstructBasis will return 
%coordinate values alpha and beta
%reconstructed vector b
[coords, b_reconstruct] = reconstructBasis(b, c_1, c_2);
distance = norm(b_reconstruct - b);

%allows alpha and beta to be printed nicely
alpha = char(945);
beta = char(946);

fprintf('<Question 2>\n\n');
fprintf('Using the following coordinates the reconstruction of b is shown below \n\n');
fprintf('%s = %f', alpha, coords(1));
fprintf('    %s = %f \n\n', beta, abs(coords(2)));
disp(['b_reconstruct = ' mat2str(b_reconstruct',2)]);
fprintf('\nThe distance between b and the reconstruction of b is \n\n    %f \n', distance);
fprintf('__________________________________________________________________________\n');

end


function [laplacianMask2] = laplacianMask2(paddedImage)
% Input Arguments:
%                *paddedImage: image matrix that has already been padded
% Output Arguements:
%                  *laplacianMask2: returns the result of convoling a
%                  laplacian mask with every pixel in the image. Returns
%                  the edges.
%
% ***Different than function laplacianMask() function because 8 values
% enclosing the point f(x,y) are used where as in laplacianMask() only 4
% values surrounding f(x,y) are used.           

[rows cols] = size(paddedImage);
laplacianMask2 = zeros(rows-2,cols-2);

for i = 2:(cols-1) %columns
    for j = 2:(rows-1) %rows
        laplacianMask2(j-1, i-1) = (-8*paddedImage(j,i))+(paddedImage(j,i-1))+(paddedImage(j,i+1))...
            +(paddedImage(j-1,i))+(paddedImage(j+1,i)+paddedImage(j-1,i-1)...
            +paddedImage(j+1,i-1)+paddedImage(j-1,i+1)+paddedImage(j+1,i+1));
    end
end


end

function [laplacianMask] = laplacianMask(paddedImage)
% Input Arguments:
%                *paddedImage: image matrix that has already been padded
% Output Arguements:
%                  *laplacianMask: returns the result of convoling a
%                  laplacian mask with every pixel in the image. Returns
%                  the edges.
%                                 

[rows cols] = size(paddedImage);
laplacianMask = zeros(rows-2,cols-2);

for i = 2:(cols-2) 
    for j = 2:(rows-2)
        laplacianMask(j-1,i-1) = (-4*paddedImage(j,i))+(paddedImage(j,i-1))...
            +(paddedImage(j,i+1))+(paddedImage(j-1,i))+(paddedImage(j+1,i));
    end
end

end

function [paddedMatrix] = padMatrix(matrix)
% Input Arguments:
%                *matrix: matrix to be padded
% Output Arguements:
%                  *paddedMatrix: returns a matrix padded with zeros
%                                 around the borders

originalSize = size(matrix);

newMat = [zeros(originalSize(1),1),matrix, zeros(originalSize(1),1)];
sizeOfMat = size(newMat);

paddedMatrix = [zeros(1, sizeOfMat(2));newMat;zeros(1, sizeOfMat(2))];

end
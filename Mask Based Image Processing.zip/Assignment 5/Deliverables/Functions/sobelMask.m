function [sobelMask] = sobelMask(paddedImage)
% Input Arguments:
%                *paddedImage: image matrix that has already been padded
% Output Arguements:
%                  *sobelMask: returns the result of convoling a
%                  sobel mask with every pixel in the image. Returns the
%                  edges.
%                                 

[rows cols] = size(paddedImage);
sobelMask = zeros(rows-2,cols-2);

for i = 2:(cols-2) 
    for j = 2:(rows-2)
        sobelMask(j-1,i-1) = (-2*paddedImage(j,i))+(paddedImage(j+1,i))...
            +(paddedImage(j,i+1));
    end
end

end
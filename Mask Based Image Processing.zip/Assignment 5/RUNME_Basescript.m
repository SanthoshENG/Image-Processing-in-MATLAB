%%
% Assignment 5: Masked Based Image Processing
% Santhosh Nandakumar
% 301300261
% snandaku@sfu.ca
% Running this file will provide with all the outputs
% To see more detailed outlining of code please navigate to ./Deliverables
% directory where all outputs/code can be found

clear all;
close all
clc;
addpath('./Deliverables/Functions');
addpath('./Deliverables/Image');

grayScaleImage = imread('./Deliverables/Image/Clooney.jpg');
grayScaleImage = rgb2gray(grayScaleImage);
grayScaleImage = mat2gray(grayScaleImage);

%pads the grayscale mug shot with zero on the borders
paddedGray = padMatrix(grayScaleImage);


%%%%%%%%%%%%%%%% Question 1 %%%%%%%%%%%%%%%%%%%%
%% Different Edge Detection Algorithms

sobelEdges = sobelMask(paddedGray);
laplacianEdges = laplacianMask(paddedGray);
laplacianEdges2 = laplacianMask2(paddedGray);


% Plotting the results
figure('Name', ['Edge Detection'])
% Plot Sobel Mask
subplot (1,3,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(sobelEdges);
title('Sobel Edges');

%Plot Laplacian Mask (just edges)
subplot(1,3,2);
imshow(laplacianEdges);
title('Laplacian Composite #1 Edges');

%Plot enhanced image using the Laplacian Mask
subplot (1,3,3);
imshow(laplacianEdges2)
title('Laplacian Composite #2 Edges');


%%%%%%%%%%%%%%%% Question 2 (Different Masks) %%%%%%%%%%%%%%%%%%%%
%% Sobel Filter

enhancedSobel =  grayScaleImage - sobelEdges;

figure('Name', ['Sobel Filter'])
% Plot Original image
subplot (1,3,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(grayScaleImage);
title('Original Image');

%Plot Sobel Mask (just edges)
subplot(1,3,2);
imshow(sobelEdges);
title('Edges of Sobel Mask');

%Plot enhanced image using Sobel Mask 
subplot (1,3,3);
imshow(enhancedSobel)
title('Enhanced Image');

%% Laplacian Filter (4 pixel values surrounding the point)

% computing the enhanced image
enhancedLaplacian1 = (grayScaleImage - laplacianEdges);

% Plotting the results
figure('Name', ['Laplacian Filter 1'])
% Plot Original Image
subplot (1,3,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(grayScaleImage);
title('Original Image');

%Plot Laplacian Mask (just edges)
subplot(1,3,2);
imshow(laplacianEdges);
title('Edges of Laplacian Mask #1');

%Plot enhanced image using the Laplacian Mask
subplot (1,3,3);
imshow(enhancedLaplacian1)
title('Enhanced Image');


%% Laplacian Filter 2 (8 pixel values surrounding the point)

enhancedLaplacian2 = (grayScaleImage - laplacianEdges2);

figure('Name', ['Laplacian Filter 2'])
% Plot Original image
subplot (1,3,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(grayScaleImage);
title('Original Image');

%Plot Laplacian Mask #2 (just edges)
subplot(1,3,2);
imshow(laplacianEdges2);
title('Edges of Composite Laplacian Mask #2');

%Plot enhanced image using Laplacian Mask #2
subplot (1,3,3);
imshow(enhancedLaplacian2)
title('Enhanced Image');



%% Cascaded filter
% displays the linearity property of the filters
% Cascades all the filters used above
cascadedMask = (sobelEdges + laplacianEdges + laplacianEdges2);
cascadedFilter = grayScaleImage - cascadedMask;

figure('Name', ['Cascaded filter'])
% Plot Original image
subplot (1,3,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(grayScaleImage);
title('Original Image');

%Plot Cascaded Mask (just edges)
subplot(1,3,2);
imshow(cascadedMask);
title('Edges of Cascaded Mask');

%Plot enhanced image using Cascaded masks from above sections
subplot (1,3,3);
imshow(cascadedFilter)
title('Enhanced Image by Cascading');

%% Scaling Edges with Scalars
% In the following section the effect of scaling the mask with constants
% will be shown. For simplicity sake the effects of making scalar A greater
% than -1, equal to -1 and less than -1 will be shown.
% See report for further discussion

A = -0.5;
B = -1;
C = -1.5;

%%%%%%%%%%%% Sobel filter %%%%%%%%%%%%

enhancedSobelA = (grayScaleImage + A*sobelEdges);
enhancedSobelB = (grayScaleImage + B*sobelEdges);
enhancedSobelC = (grayScaleImage + C*sobelEdges);

figure('Name', ['Sobel Filter with vaying scalar A'])
title('Sobel Filter with varying scalar A')
% Plot Original image
subplot (1,4,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(grayScaleImage);
xlabel(['Original Image']);

% Plot Sobel enhanced image with scale factor A
subplot (1,4,2)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(enhancedSobelA);
xlabel(['A = -0.5']);

% Plot Sobel enhanced image with scale factor B
subplot(1,4,3);
imshow(enhancedSobelB);
xlabel(['A = -1.0']);

% Plot Sobel enhanced image with scale factor C
subplot (1,4,4);
imshow(enhancedSobelC)
xlabel(['A = -1.5']);

%%%%%%%%%%%% Laplacian filter #1 %%%%%%%%%%%%

enhancedLaplacianA = (grayScaleImage + A*laplacianEdges);
enhancedLaplacianB = (grayScaleImage + B*laplacianEdges);
enhancedLaplacianC = (grayScaleImage + C*laplacianEdges);

figure('Name', ['Laplacian Filter #1 with vaying scalar A'])
title('Laplacian Filter #1 Filter with varying scalar A')
% Plot Original image
subplot (1,4,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(grayScaleImage);
xlabel(['Original Image']);

% Plot Laplacian #1 enhanced image with scale factor A
subplot (1,4,2)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(enhancedLaplacianA);
xlabel(['A = -0.5']);

% Plot Laplacian #1 enhanced image with scale factor B
subplot(1,4,3);
imshow(enhancedLaplacianB);
xlabel(['A = -1.0']);

% Plot Laplacian #1 enhanced image with scale factor C
subplot (1,4,4);
imshow(enhancedLaplacianC)
xlabel(['A = -1.5']);

%%%%%%%%%%%% Laplacian filter #2 %%%%%%%%%%%%

enhancedLaplacian2A = (grayScaleImage + A*laplacianEdges2);
enhancedLaplacian2B = (grayScaleImage + B*laplacianEdges2);
enhancedLaplacian2C = (grayScaleImage + C*laplacianEdges2);

figure('Name', ['Laplacian Filter #2 with vaying scalar A'])
title('Laplacian Filter #2 Filter with varying scalar A')
% Plot Original image
subplot (1,4,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(grayScaleImage);
xlabel(['Original Image']);

% Plot Laplacian #2 enhanced image with scale factor A
subplot (1,4,2)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(enhancedLaplacian2A);
xlabel(['A = -0.5']);

% Plot Laplacian #2 enhanced image with scale factor B
subplot(1,4,3);
imshow(enhancedLaplacian2B);
xlabel(['A = -1.0']);

% Plot Laplacian #2 enhanced image with scale factor C
subplot (1,4,4);
imshow(enhancedLaplacian2C)
xlabel(['A = -1.5']);

%%%%%%%%%%%% Cascaded filter %%%%%%%%%%%%

cascadedFilterA = grayScaleImage + A*cascadedMask;
cascadedFilterB = grayScaleImage + B*cascadedMask;
cascadedFilterC = grayScaleImage + C*cascadedMask;

figure('Name', ['Cascaded Filter with vaying scalar A'])
title('Cascaded Filter with varying scalar A')
% Plot Original image
subplot (1,4,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(grayScaleImage);
xlabel(['Original Image']);

% Plot Cascaded enhanced image with scale factor A
subplot (1,4,2)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(cascadedFilterA);
xlabel(['A = -0.5']);

% Plot Cascaded enhanced image with scale factor B
subplot(1,4,3);
imshow(cascadedFilterB);
xlabel(['A = -1.0']);

% Plot Cascaded enhanced image with scale factor C
subplot (1,4,4);
imshow(cascadedFilterC)
xlabel(['A = -1.5']);


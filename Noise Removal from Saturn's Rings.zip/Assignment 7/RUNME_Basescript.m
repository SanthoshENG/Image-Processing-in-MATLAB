%%
% Assignment 7: Removing Random and Periodic noise
% Santhosh Nandakumar
% 301300261
% snandaku@sfu.ca
% Running this file will provide with all the outputs
% To see more detailed outlining of code please navigate to ./Deliverables
% directory where all outputs/code can be found
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NOTE All subplot titles do not run on other machines, however it works on
% my computer but I have commented it out just in case it does not run. For
% titles please look at the report
clear all;
close all
clc;
addpath('./Deliverables/Functions');
addpath('./Deliverables/Images');

satRing = imread('./Deliverables/Images/SaturnRingWithRandomNoise.jpg');
[rows cols] = size(satRing);

fftSatRing = fft2(satRing);
fftShiftedSatRing = fftshift(fftSatRing);

%Padded with one extra zero column since there are an odd number of columns
paddedRings = padarray(fftShiftedSatRing, [0 1], 0, 'post');
filter = bandRejectFilter(paddedRings, 113, 1);
%Removes additional column added to ensure there is center column 
filter = filter(:,1:end-1);

bandRejectFilter = ifft2(fftshift(fftShiftedSatRing.*filter));
finalImage = medianMask(bandRejectFilter, 3);

%Periodic noise 
noise = fftSatRing(:,1);
noiseMat = ifft2(padarray(noise, [0,cols],0,'post'));


% Show Periodic Noise Removal
figure('Name', ['Periodic Noise Removal'])
% Plot Original image
subplot (1,3,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(satRing, []);
xlabel(['Saturn Ring With Noise']);

subplot (1,3,2)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(noiseMat, []);
xlabel(['Periodic Noise']);

subplot(1,3,3);
set(gcf, 'Position', get(0, 'Screensize'));
imshow(bandRejectFilter, []);
xlabel(['Band Reject Filter Applied to Remove Periodic Noise']);
%suptitle('Removing Periodic Noise');


%Show histogram to identitfy (Random Noise) salt and pepper noise
figure('Name', ['Histogram of Random Noise'])
subplot (1,2,1)
set(gcf, 'Position', get(0, 'Screensize'));
imhist(rescale(bandRejectFilter));
ylabel('Number of pixels')
title('Histogram with Random Noise')

subplot (1,2,2)
set(gcf, 'Position', get(0, 'Screensize'));
imhist(rescale(finalImage));
ylabel('Number of pixels')
title('Histogram with Random Noise (Salt and Pepper) Removed')
%suptitle('Histogram of Before and After Noise Removal');


%Show random noise removal (salt and pepper)
figure('Name', ['Random Noise Removal'])
% Plot Original image
subplot (1,2,1)
set(gcf, 'Position', get(0, 'Screensize'));
imshow(bandRejectFilter, []);
xlabel(['Saturn Ring After Removing Periodic Noise']);

subplot(1,2,2);
set(gcf, 'Position', get(0, 'Screensize'));
imshow(finalImage, []);
xlabel(['Median Filter Applied to Remove Salt and Pepper (Random) Noise']);
%suptitle('Removing Random (Salt and Pepper) Noise');

%Show Final Nosie Removal Pipeline
figure('Name', ['Noise Removal Pipeline']);
% Plot Original image
subplot (1,3,1);
set(gcf, 'Position', get(0, 'Screensize'));
imshow(satRing, []);
xlabel(['Saturn Ring With Noise']);

subplot(1,3,2);
set(gcf, 'Position', get(0, 'Screensize'));
imshow(bandRejectFilter, []);
xlabel(['Band Reject Filter Applied to Remove Periodic Noise']);

subplot (1,3,3);
set(gcf, 'Position', get(0, 'Screensize'));
imshow(finalImage, []);
xlabel(['Median filter Applied to remove Salt and Pepper Noise']);
%suptitle('Noise Removal Pipeline');




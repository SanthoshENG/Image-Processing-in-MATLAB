function filteredImage = medianMask(image,maskSize)
% Input Arguments:
%                *image: image matrix that will be padded
%                *maskSize: size of the mask (must be a positive integer)
% Output Arguements:
%                  *filteredImage: returns the filtered image after median 
%                   filtering. Center pixel is replaced with the median value 
%                   present in the mask.
  

%Predetermined filtered image size which matches the original input image
filteredImage = zeros(size(image));

image = padarray(image,[floor(maskSize/2) floor(maskSize/2)],0,'both');
 


%Normalized component which helps to smooth
[numRows numCols] = size(image); 
c = 1/(maskSize^2);
mask = c*ones(maskSize, maskSize);

%2 for loops used
%First loop is entered if mask is odd
%Second loop is entered if mask is even
if mod(maskSize,2) == 1
    for i = (ceil(maskSize/2)):(numRows-floor(maskSize/2))
        for j = (ceil(maskSize/2)):(numCols-floor(maskSize/2))
         currentMask = ...
            image(i-floor(maskSize/2):i+floor(maskSize/2),...
            j-floor(maskSize/2):j+floor(maskSize/2));
        currentMask = currentMask(:);
        filteredImage(i-(floor(maskSize/2)),j-(floor(maskSize/2)))= median(currentMask(:));
        end
    end
else
    for i = (ceil(maskSize/2)):(numRows-floor(maskSize/2))
        for j = (ceil(maskSize/2)):(numCols-floor(maskSize/2))
         currentMask = ...
            sum(sum(mask.*image(i-floor(maskSize/2)+1:i+floor(maskSize/2),...
            j-floor(maskSize/2)+1:j+floor(maskSize/2))));
            currentMask = currentMask(:);
         filteredImage(i-(floor(maskSize/2))+1,j-(floor(maskSize/2))+1) = currentMask;
         
        end
    end
end



% imageAsColumn = im2col(paddedImage,[maskSize maskSize],'sliding');
% sortedColumns = sort(imageAsColumn,1, 'ascend');
% medianVector = sorted_cols(floor(maskSize*maskSize/2)+1, :);
% filteredImage = col2im(medianVector, [maskSize maskSize], size(paddedImage),'sliding');
% 
% im_col = im2col(im_pad, [N N], 'sliding');
% sorted_cols = sort(im_col, 1, 'ascend');
% med_vector = sorted_cols(floor(N*N/2) + 1, :);
% out = col2im(med_vector, [N N], size(im_pad), 'sliding');



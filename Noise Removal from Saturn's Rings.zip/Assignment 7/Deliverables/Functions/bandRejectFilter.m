function [filter] = bandRejectFilter(image, height, width)
% Input Arguments:
%                *image: a band reject filter will be constructed for the
%                followng image
%                *height: height of filter (number of rows)
%                *width: width of of filter (number of columns)
% Output Arguements:
%                  *filter: returns the band reject filter which is used to
%                  remove intermediated frequenncies. Specific to when the
%                  periodic noise frequency only varies in the veritical
%                  direction.

[rows cols] = size(image);

centerMat = ones(rows, width);
top = padarray(-1*ones(height, width),[rows-height,0],'post');
bottom = padarray(-1*ones(height, width),[rows-height,0],'pre');
passBand = centerMat + top + bottom;

%Ensures functionalty of even and odd cases for the filter and image dimensions 
if (mod(cols,2) == 1 && mod(width,2) == 1)
    filter = [ones(rows,round((cols+1)/2)-(width+1)/2) passBand ones(rows,round((cols-1)/2)-(width-1)/2)];
elseif(mod(cols,2) == 1 && mod(width,2) == 0) 
    filter = [ones(rows,round((cols+1)/2)-(width)/2) passBand ones(rows,round((cols-1)/2)-(width)/2)];
elseif(mod(cols,2) == 0 && mod(width,2) == 1) 
    filter = [ones(rows,round((cols)/2)-(width+1)/2) passBand ones(rows,round((cols)/2)-(width-1)/2)];
else
    filter = [ones(rows,round((cols)/2)-width/2) passBand ones(rows,round(cols/2)-width/2)];
end
end


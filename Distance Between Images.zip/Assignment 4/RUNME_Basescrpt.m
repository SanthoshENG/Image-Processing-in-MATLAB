%%
% Assignment 4: Distance Between Images
% Santhosh Nandakumar
% 301300261
% snandaku@sfu.ca
% Running this file will provide with all the outputs
% To see more detailed outlining of code please navigate to ./Deliverable
% directory where all outputs/code can be found
clear all;
close all
clc;
% addpath('./Deliverables/Questions/Question 1');
% addpath('./Deliverables/Questions/Question 2');
addpath('./Deliverables/Functions');
addpath('./Deliverables/Images');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% TA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% PLEASE CHANGE THE VARIABLE "yaleFolderPath" TO THE PATH YOUR "CroppedYale" FOLDER %%%  

yaleCroppedFolderPath = 'C:\Users\Santhosh\Documents\CroppedYale\CroppedYale';
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
%defaultDir stores the current directory of the Basescript
defaultDir = cd;
% 
% %changes directory into the CroppedYale folder from extraction of subdirectory names 
cd (['',yaleCroppedFolderPath,'']);
% 
% %structure holding all the directory information
folderList = dir;
% 
% % The following code removes the first 2 directorys which are . and .. 
% % The . and .. correspond to the parent directory of the subfolders
folderList(1)=[];
folderList(1)=[];
listFolderName = {folderList.name};

%changes back to the directory of the Basescript
cd (['',defaultDir,'']);

numOfSubFolders = size(listFolderName);
numOfSubFolders = numOfSubFolders(2);


% for loop performs computations for all 38 subjects
for i=1:numOfSubFolders
    
    folderName = ([yaleCroppedFolderPath,'\',listFolderName{i}]);


    [subjectImages, dims] = imagesFromFolder(folderName);
    %%%%%%% All computations performed %%%%%%%%
    % Computes mean of images in a subfolder
    meanSubject = meanImage(subjectImages,dims);
    % Computes variance of the images with respect to the mean image of
    % the subfolder
    varianceV = variance(meanSubject,subjectImages);
    % Computes Euclidean distance between each image and the mean
    eDistance = euclideanDistance(meanSubject, subjectImages);
    % Computes Penrose distance between each image and the mean
    pDistance = penroseDistance(meanSubject,varianceV, subjectImages);
    
    
    %subplots the Mean Image alongside Euclidean vs Penrose Distance of
    %every subject
    %Conditional statements are used to compensate for the fact that there
    %is no 14th subject
    if i >= 14
        i = i+1;
        figure('name',['Subject ',num2str(i),' Statistics'])
        subplot(1,2,1);
        imshow( meanSubject, [min(meanSubject(:)), max(meanSubject(:))]);
        title(['Subject ', num2str(i), ' Mean Image']);
        subplot(1,2,2);
        scatter(eDistance,pDistance,'r')
        title('Euclidean vs. Penrose Distance')
        xlabel(['Euclidean Distance'])
        ylabel(['Penrose Distance']) 
        i = i-1;
    else
        figure('name',['Subject ',num2str(i),' Statistics'])
        subplot(1,2,1);
        imshow( meanSubject, [min(meanSubject(:)), max(meanSubject(:))]);
        title(['Subject ', num2str(i), ' Mean Image']);
        subplot(1,2,2);
        scatter(eDistance,pDistance,'r')
        title('Euclidean vs. Penrose Distance')
        xlabel(['Euclidean Distance'])
        ylabel(['Penrose Distance']) 
    end

     %Saves the output figures to the proper subfolder
     %The saved images can be found in /Deliverables/Output Figures/      
     %outStr = strcat('/Deliverables/Output Figures/', 'Subject', num2str(i),'.png');
     %saveas(figure(i),[pwd outStr]);
      

end
%% Bonus Question

%The image that is being reconstructed
I = getpgmraw('yaleB18_P00A+015E+20.pgm');
dimsI = size(I);
I = I(:);

%hard coded basis vectors
basis_1 = getpgmraw('yaleB28_P00A-015E+20.pgm');
basis_1 = basis_1(:);
basis_2 = getpgmraw('yaleB28_P01A+015E+20.pgm');
basis_2 = basis_2(:);
basis_3 = getpgmraw('yaleB28_P02A+015E+20.pgm');
basis_3 = basis_3(:);
basis_4 = getpgmraw('yaleB28_P03A-015E+20.pgm');
basis_4 = basis_4(:);
basis_5 = getpgmraw('yaleB28_P04A-015E+20.pgm');
basis_5 = basis_5(:);
basis_6 = getpgmraw('yaleB28_P05A-015E+20.pgm');
basis_6 = basis_6(:);
basis_7 = getpgmraw('yaleB28_P06A+015E+20.pgm');
basis_7 = basis_7(:);

%Call to reconstructBasis will return the coordinates of the reoconstructed
%Image and the actual reconstructed Image
[coords,reconstructedI] = reconstructBasis(I,basis_1,basis_2,basis_3,basis_4,basis_5,basis_6,basis_7);
reconstructedI = reshape(reconstructedI,dimsI);
I = reshape(I, dimsI);

%Plots the original Image "I" and the reconstructed Image "I"

figure('name','Bonus Question Reconstructed Image of I')
subplot(1,2,1);
imshow( I, [min(I(:)), max(I(:))]);
title(['Original Image "I"'])
subplot(1,2,2);
imshow( reconstructedI, [min(reconstructedI(:)), max(reconstructedI(:))]);
title(['Reconstructed Image I']);
disp('The coordinates used in the basis reconstruction are shown below')
disp(coords)




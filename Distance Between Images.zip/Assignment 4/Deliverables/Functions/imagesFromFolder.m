function [imageList,imageDims] = imagesFromFolder(directoryPath)

% Input arguements: 
%      -directoryPath: is a string holding the absolute path of subfolder
% Output
%      -imageList: is a cell of column vectors where each colum vector is an
%       image from the subfolder
%      -imageDims: returns the dimensions of the image (assuming there are
%       all the same since they are for this application)

%Stores the current directory
defaultDir = cd;

%Sets up type of file to look for
filetype = '/*.pgm';
srcFiles = dir(strcat(directoryPath,filetype));  % the folder in which ur images exists

importImages = cell(1,numel(srcFiles)-1);

%Changes directory into the specified subdirectory 
%in this case it would span yaleB01 to yaleB39 depending on the current
%iteration in the RUNME_Basescript
cd (['',directoryPath,'']);

%Iterates through all the images in the subFolder which are type .pgm and
%process them using getpgmraw()
for i = 1 : (length(srcFiles)-1)

    filename = srcFiles(i).name; 
    image = getpgmraw(filename);
    sizeImage = size(image);
    importImages{i} = image(:);
    
   
end
%Changes back to proper directory
cd (['',defaultDir,''])
imageList = importImages;
imageDims = sizeImage;


function [euclideanDVector] = euclideanDistance(meanImage, sampleImages)

% Input arguements: 
%      -meanImage is the mean image of the subject
%      -sampleImage is a type cell conataining all images for a subject
% Output
%      -euclideanDVector is a vector which stores all the Euclidean
%       distances of each image in the folder to the mean image


numOfImages = size(sampleImages);
numOfImages = numOfImages(2);
imageMatrices = cell2mat(sampleImages);
meanImage = meanImage(:);

for i=1:numOfImages

    euclideanDistance(i) = sqrt(sum((meanImage - imageMatrices(:,i)).^2));
    
end

euclideanDVector = (euclideanDistance-min(euclideanDistance(:))) ./ (max(euclideanDistance(:)-min(euclideanDistance(:))));

end




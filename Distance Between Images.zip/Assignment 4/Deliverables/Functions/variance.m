function [variance] = variance(meanImage, sampleImages)

% Input arguements: 
%      -meanImage is a matrix of the mean image for a subject
%      -sampleImage is a type cell conataining all images for a subject
% Output
%      -variance is a column vector holding how many images in the subfolder
%       vary from the mean image

imageDims = size(meanImage);
meanImage = meanImage(:);
imageMatrix = cell2mat(sampleImages);

numOfImages = size(sampleImages);
numOfImages = numOfImages(2);
intermediate = ((imageMatrix(:,1)-meanImage).^2);


for i = 2:numOfImages
    
    insideSum = (imageMatrix(:,i)-meanImage).^2;
    intermediate = plus(intermediate,insideSum);
    
end

variance = intermediate/numOfImages;
%varianceMatrix = reshape(varianceMatrix,imageDims);
    
end
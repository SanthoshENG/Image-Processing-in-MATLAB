function [penroseDVector] = penroseDistance(meanImage,variance, sampleImages)

% Input arguements: 
%      -meanImage is the mean image of the subject
%      -variance is a matrix holding how much the images in the subfolder
%       vary from the mean image of that folder
%      -sampleImage is a type cell conataining all images for a subject
% Output
%      -penroseDVector is a vector which stores all the Penrose
%       distances of each image in the folder to the mean image

numOfImages = size(sampleImages);
numOfImages = numOfImages(2);
imageMatrices = cell2mat(sampleImages);
meanImage = meanImage(:);

for i=1:numOfImages

    penroseDistance(i) = sum((((meanImage - imageMatrices(:,i)).^2))./((variance+0.0000001)));
    
end

penroseDVector = (penroseDistance-min(penroseDistance(:))) ./ (max(penroseDistance(:)-min(penroseDistance(:))));


end

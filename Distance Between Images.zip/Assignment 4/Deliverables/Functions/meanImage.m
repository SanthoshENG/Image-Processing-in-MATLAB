function [meanImageMatrix] = meanImage(Images,imageDims)

% Input arguements: 
%      -Images is a type cell conataining all images for a subject
%      -imageDims the dimension of the images in subfolder
% Output
%      -meanImageMatrix is a mean image matrix

numOfImages = size(Images);
imageMatrix = cell2mat(Images);
meanImage = sum(imageMatrix,2)./numOfImages(2);
meanImageMatrix = reshape(meanImage,imageDims);
end